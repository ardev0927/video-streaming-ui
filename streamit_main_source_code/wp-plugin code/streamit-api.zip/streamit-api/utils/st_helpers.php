<?php


function stValidationToken ($request) {
	$data = [
		'message' => 'Valid token',
        'status' => true,
        'status_code' => 200
	];
	$response = collect((new Jwt_Auth_Public('jwt-auth', '1.1.0'))->validate_token($request, false));
    $pms_settings = get_option( 'pms_general_settings' );
    
	if ($response->has('errors')) {
		$data['status'] = false;
		$data['message'] = isset(array_values($response['errors'])[0][0]) ? array_values($response['errors'])[0][0] : __("Authorization failed");
	}else {
        $header = $request->get_headers();
        $current_user_id = get_current_user_id();
        $user_id =  $current_user_id != 0 ? $current_user_id : null;
        $account_sharing = ( isset( $pms_settings['prevent_account_sharing'] ) && !empty( $pms_settings['prevent_account_sharing'] ) );
        if( $account_sharing && !empty($header['authorization']) && $header['authorization'][0] != null ){
            $session_tokens = get_user_meta($user_id, 'session_tokens',true);

            list($header_token) = sscanf($header['authorization'][0] , 'Bearer %s');
            if ( $header_token != $session_tokens ) {
                $data['status'] = false;
                $data['message'] = 'You are already logged in on another device';
                $data['status_code'] = 401;
            } else {
                $data['user_id'] = $user_id;
            }
        } else {
            $data['user_id'] = $user_id;
        }
    }
	return $data;
}

function stValidateRequest($rules, $request, $message = [])
{
	$error_messages = [];
	$required_message = ' field is required';
	$email_message =  ' has invalid email address';

	if (count($rules)) {
		foreach ($rules as $key => $rule) {
			if (strpos($rule, '|') !== false) {
				$ruleArray = explode('|', $rule);
				foreach ($ruleArray as $r) {
					if ($r === 'required') {
						if (!isset($request[$key]) || $request[$key] === "" || $request[$key] === null) {
							$error_messages[] = isset($message[$key]) ? $message[$key] : str_replace('_', ' ', $key) . $required_message;
						}
					} elseif ($r === 'email') {
						if (isset($request[$key])) {
							if (!filter_var($request[$key], FILTER_VALIDATE_EMAIL) || !is_email($request[$key]) ) {
								$error_messages[] = isset($message[$key]) ? $message[$key] : str_replace('_', ' ', $key) . $email_message;
							}
						}
					}
				}
			} else {
				if ($rule === 'required') {
					if (!isset($request[$key]) || $request[$key] === "" || $request[$key] === null) {
						$error_messages[] = isset($message[$key]) ? $message[$key] : str_replace('_', ' ', $key) . $required_message;
					}
				} elseif ($rule === 'email') {
					if (isset($request[$key])) {
                        if (!filter_var($request[$key], FILTER_VALIDATE_EMAIL) || !is_email($request[$key]) ) {
							$error_messages[] = isset($message[$key]) ? $message[$key] : str_replace('_', ' ', $key) . $email_message;
						}
					}
				}
			}

		}
	}

	return $error_messages;
}


function stRecursiveSanitizeTextField($array)
{
	$filterParameters = [];
	foreach ($array as $key => $value) {

		if ($value === '') {
			$filterParameters[$key] = null;
		} else {
			if (is_array($value)) {
				$filterParameters[$key] = stRecursiveSanitizeTextField($value);
			} else {
				if (preg_match("/<[^<]+>/", $value, $m) !== 0) {
					$filterParameters[$key] = $value;
				} else {
					$filterParameters[$key] = sanitize_text_field($value);
				}
			}
		}

	}

	return $filterParameters;
}

function stGetErrorMessage ($response) {
	return isset(array_values($response->errors)[0][0]) ? array_values($response->errors)[0][0] : __("Internal server error");
}

function stGenerateString($length_of_string = 10)
{
	// String of all alphanumeric character
	$str_result = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
	return substr(str_shuffle($str_result),0, $length_of_string);
}

function comman_message_response( $message, $status_code = 200)
{
    $response = new WP_REST_Response(array(
            "message" => $message
        )
    );
    $response->set_status($status_code);
    return $response;
}

function comman_custom_response( $res, $status_code = 200 )
{
    $response = new WP_REST_Response($res);
    $response->set_status($status_code);
    return $response;
}

function comman_list_response( $data )
{
    $response = new WP_REST_Response(array(
        "data" => $data
    ));

    $response->set_status(200);
    return $response;
}


function streamit_movie_video_detail_helper($id,$user_id = null){
    $list = get_post($id);

    if( empty($list) && $list === null) {
        return [];
    }
    $id = $list->ID;
    $post_meta     = get_post_meta($id);
    $avg_rating    = $post_meta['_masvideos_average_rating'][0];
    
    $image = wp_get_attachment_image_src(get_post_thumbnail_id($list->ID), [300, 300]);
    $temp = [
        'id'                => $list->ID,
        'title'             => get_the_title($id),
        'image'             => !empty($image) ? $image[0] : null,
        'post_type'         => $list->post_type,
        'description'       => apply_filters( 'the_content', get_the_content(null,false,$list->ID) ),
        'excerpt'           => wp_strip_all_tags(get_the_excerpt($list)),
        'share_url'         => get_the_permalink($list->ID),
        'is_comment_open'   => comments_open($list->ID),
    ];

    $subscription_plan = isset($post_meta['pms-content-restrict-subscription-plan']) ? $post_meta['pms-content-restrict-subscription-plan'] : null;
    if ( !empty($subscription_plan) && count($subscription_plan) > 0 ) {
        $temp['restrict_subscription_plan'] = collect($subscription_plan)->map( function  ($plan) {
            $plan_data = [
                'id'    => $plan,
                'label' => get_the_title($plan),
            ];
            return $plan_data;
        });
    } else {
        $temp['restrict_subscription_plan'] = [];
    }
    $temp['is_post_restricted'] = pms_is_post_restricted($list->ID);
    $user_has_pms_member = pms_is_member_of_plan($subscription_plan,$user_id);
    $temp['user_has_pms_member'] = $user_has_pms_member;
    $temp['restrict_user_status'] = get_post_meta($id, 'pms-content-restrict-user-status', true);
    $temp['restriction_setting'] = streamit_get_content_restriction_settings($list->ID, $user_has_pms_member,$user_id);
    // Old status
    if ( $temp['restrict_user_status'] == 'loggedin'  || ( !empty($subscription_plan) && count($subscription_plan) > 0 ) ){
        $temp['restriction_settings'] = get_content_restriction_settings($list->ID,$user_id);
    } else {
        $temp['restriction_settings'] = (object) [
            'restrict_type' => ''
        ];
    }

    if( $list->post_type === 'movie' ) {
        $temp['run_time'] = $post_meta['_movie_run_time'][0];
        $temp['censor_rating']     = $post_meta['_movie_censor_rating'][0];
    }
    if( $list->post_type === 'video' ) {
        $temp['run_time'] = $post_meta['_video_run_time'][0];
    }
    if( $list->post_type === 'episode' ){
        $temp['run_time']   = $post_meta['_episode_run_time'][0];
    }
    
    if( in_array($list->post_type , ['movie','tv_show' ,'video']) ){
        $logo = isset($post_meta['name_logo']) ? wp_get_attachment_image_src($post_meta['name_logo'][0],[300, 300]) : null;
        
        if (!(empty($logo))) {
            $temp['logo'] = $logo[0];
        } else {
            $temp['logo'] = null;
        }
        $temp['cast']           = get_cast_crew_helper($list->ID , '_cast');
        $temp['casts']          = streamit_cast_detail_helper($list->ID);
    }
    
    $temp['trailer_link']   = !empty($post_meta['name_trailer_link'][0]) ? $post_meta['name_trailer_link'][0] : null;

    return $temp;
}

function streamit_movie_video_detail_helper_detail($id,$user_id = null){
    $list = get_post($id);

    if( empty($list) && $list === null) {
        return [];
    }
    $id = $list->ID;
    $post_meta     = get_post_meta($id);
    $avg_rating    = $post_meta['_masvideos_average_rating'][0];
    
    $image = wp_get_attachment_image_src(get_post_thumbnail_id($list->ID), [300, 300]);
    $temp = [
        'id'                => $list->ID,
        'title'             => get_the_title($id),
        'image'             => !empty($image) ? $image[0] : null,
        // 'description'       => wp_strip_all_tags(get_the_content(null,false,$id)),
        'description'       => apply_filters( 'the_content', get_the_content(null,false,$list->ID) ),
        'excerpt'           => wp_strip_all_tags(get_the_excerpt($list)),
        'is_featured'       => !empty($post_meta['__featured'][0]) && $post_meta['__featured'][0] === 'yes' ? true : false,
        // 'image'             => streamit_get_movie_video_images_helper($list),
        'likes'             => wp_ulike_get_post_likes($list->ID),
        'post_type'         => $list->post_type,
        'name_upcoming'     => isset($post_meta['name_upcoming']) ? $post_meta['name_upcoming'][0] : null,
        'share_url'         => get_the_permalink($list->ID),
        'is_comment_open'   => comments_open($list->ID),
    ];

    $subscription_plan = isset($post_meta['pms-content-restrict-subscription-plan']) ? $post_meta['pms-content-restrict-subscription-plan'] : null;
    if ( !empty($subscription_plan) && count($subscription_plan) > 0 ) {
        $temp['restrict_subscription_plan'] = collect($subscription_plan)->map( function  ($plan) {
            $plan_data = [
                'id'    => $plan,
                'label' => get_the_title($plan),
            ];
            return $plan_data;
        });
    } else {
        $temp['restrict_subscription_plan'] = [];
    }

    $temp['is_post_restricted'] = pms_is_post_restricted($list->ID);
    $user_has_pms_member = pms_is_member_of_plan($subscription_plan,$user_id);
    $temp['user_has_pms_member'] = $user_has_pms_member;
    $temp['restriction_setting'] = streamit_get_content_restriction_settings($list->ID, $user_has_pms_member,$user_id);
    
    // Old status
    $temp['restrict_user_status'] = get_post_meta($id, 'pms-content-restrict-user-status', true);
    if ( $temp['restrict_user_status'] == 'loggedin'  || ( !empty($subscription_plan) && count($subscription_plan) > 0 ) ){
        $temp['restriction_settings'] = get_content_restriction_settings($list->ID,$user_id);
    } else {
        $temp['restriction_settings'] = (object) [
            'restrict_type' => ''
        ];
    }
    
    // Old status
    if ( $temp['restrict_user_status'] == 'loggedin'  || ( !empty($subscription_plan) && count($subscription_plan) > 0 ) ){
        $temp['restriction_settings'] = get_content_restriction_settings($list->ID,$user_id);
    } else {
        $temp['restriction_settings'] = (object) [
            'restrict_type' => ''
        ];
    }
    
    if($user_id !== null){
        $temp['is_liked']       = streamit_user_liked_post($list->ID,$user_id);
        $temp['is_watchlist']   = streamit_watchlist($list->ID,$user_id);
    } else {
        $temp['is_liked']       = null;
        $temp['is_watchlist']   = null;
    }
    if( $list->post_type === 'movie' ) {
        $temp['avg_rating']        = ($avg_rating === null ? 0 : $avg_rating );
        $temp['publish_date']      = $list->post_date;
        $temp['publish_date_gmt']  = $list->post_date_gmt;
        $temp['embed_content']     = $post_meta['_movie_embed_content'][0];
        $temp['movie_choice']      = $post_meta['_movie_choice'][0];
        $movie_file = null;
        if ( $temp['movie_choice'] == 'movie_file' && !empty($post_meta['_movie_attachment_id']) && $post_meta['_movie_attachment_id'][0] != null ) {
            $movie_file = isset($post_meta['_movie_attachment_id']) ? wp_get_attachment_url($post_meta['_movie_attachment_id'][0]) : null;
        }
        $temp['movie_file'] = $movie_file;
        $temp['url_link']          = $post_meta['_movie_url_link'][0];
        $temp['tag']               = get_taxonomy_terms_helper($list , 'movie','tag');
        $temp['genre']             = get_taxonomy_terms_helper($list , 'movie','genre');
        $temp['visibility']        = get_taxonomy_terms_helper($list , 'movie','visibility');
        $temp['run_time']          = $post_meta['_movie_run_time'][0];
        $temp['censor_rating']     = $post_meta['_movie_censor_rating'][0];
        $temp['release_date']      = date_i18n(get_option( 'date_format'),$post_meta['_movie_release_date'][0]);
        $temp['views']             = isset($post_meta['post_views_count']) ? (int) $post_meta['post_views_count'][0] : 0;
    }

    if( $list->post_type === 'tv_show' ) {
        $temp['avg_rating']        = ($avg_rating === null ? 0 : $avg_rating );
        $temp['publish_date']      = $list->post_date;
        $temp['publish_date_gmt']  = $list->post_date_gmt;
        $tv_show_season = get_post_meta($id, '_seasons');
        $show_seasons = $tv_show_season[0];        
        $temp['total_seasons'] = !empty($show_seasons) ? count($show_seasons) : 0;
        $temp['tag']           = get_taxonomy_terms_helper($list , 'tv_show','tag');
        $temp['genre']         = get_taxonomy_terms_helper($list , 'tv_show','genre');
        $temp['visibility']    = get_taxonomy_terms_helper($list , 'tv_show','visibility');
    }

    if( $list->post_type === 'video' ) {
        $temp['publish_date']      = $list->post_date;
        $temp['publish_date_gmt']  = $list->post_date_gmt;
        $temp['embed_content']     = $post_meta['_video_embed_content'][0];
        $temp['video_choice']      = $post_meta['_video_choice'][0];
        $video_file = null;
        if ( $temp['video_choice'] == 'video_file' && !empty($post_meta['_video_attachment_id']) && $post_meta['_video_attachment_id'][0] != null ) {
            $video_file = isset($post_meta['_video_attachment_id']) ? wp_get_attachment_url($post_meta['_video_attachment_id'][0]) : null;
        }
        $temp['video_file'] = $video_file;
        $temp['url_link']          = $post_meta['_video_url_link'][0];
        $temp['tag']           = get_taxonomy_terms_helper($list , 'video','tag');
        $temp['cat']           = get_taxonomy_terms_helper($list , 'video','cat');
        $temp['run_time']          = $post_meta['_video_run_time'][0];
        $temp['views']             = isset($post_meta['post_views_count']) ? (int) $post_meta['post_views_count'][0] : 0;
    }

    if( in_array($list->post_type , ['movie','tv_show' ,'video']) ){
        $logo = isset($post_meta['name_logo']) ? wp_get_attachment_image_src($post_meta['name_logo'][0],[300, 300]) : null;
        
        if (!(empty($logo))) {
            $temp['logo'] = $logo[0];
        } else {
            $temp['logo'] = null;
        }
        $temp['cast']           = get_cast_crew_helper($list->ID , '_cast');
        $temp['casts']          = streamit_cast_detail_helper($list->ID);
    }
    $temp['no_of_comments'] = (int) get_comments_number($list->ID);
    $temp['trailer_link']   = !empty($post_meta['name_trailer_link'][0]) ? $post_meta['name_trailer_link'][0] : null;

    if( in_array($list->post_type , ['movie','tv_show' ,'episode']) ){
        $temp['imdb_rating'] = !empty($post_meta['name_custom_imdb_rating'][0]) ? floatval($post_meta['name_custom_imdb_rating'][0]) / 2  : 0;
    }
    if( $list->post_type === 'episode' ){
        $temp['tv_show_id'] = $post_meta['_tv_show_id'][0];
        $temp['embed_content']  = $post_meta['_episode_embed_content'][0];
        $temp['episode_choice'] = $post_meta['_episode_choice'][0];
        $episode_file = null;
        if ( $temp['episode_choice'] == 'episode_file' ) {
            $episode_file = isset($post_meta['_episode_attachment_id']) ? wp_get_attachment_url($post_meta['_episode_attachment_id'][0]) : null;
        }
        $temp['episode_file'] = $episode_file;
        $temp['url_link']     = $post_meta['_episode_url_link'][0];
        $temp['episode_number'] = $post_meta['_episode_number'][0];
        $temp['run_time']   = $post_meta['_episode_run_time'][0];
        $temp['release_date']      = date_i18n(get_option( 'date_format'),$post_meta['_episode_release_date'][0]);
        $temp['views']             = isset($post_meta['post_views_count']) ? (int) $post_meta['post_views_count'][0] : 0;
    }

    if( in_array($list->post_type , ['movie', 'episode']) )
    {
        $temp['sources'] = streamit_source_list($list->ID);
    }

    return $temp;
}

function streamit_get_content_restriction_settings($post_id, $has_member, $user_id){
    
    $message = ''; $redirect_url = ''; $restrict_type = '';
    $type = '';

    if( $has_member )
    {
        return (object) [];
    }
    if($user_id == null)
    {
        $type = 'logged_out';
    } else if($user_id != null && $has_member == false ){
        $type = 'non_members';
    }
    $post_restriction_type = get_post_meta( $post_id, 'pms-content-restrict-type', true );

    $settings = get_option('pms_content_restriction_settings', array());
    if( $post_restriction_type != 'default' ) {
        $restrict_type = $post_restriction_type;
    } else {
        $restrict_type = $settings['content_restrict_type'];
    }
    
    if( $settings['content_restrict_type'] == 'template' || $post_restriction_type == 'template' ){
        $restrict_type = 'message';
    }

    $redirect_url = get_restricted_post_redirect($post_id, $type);

    $message = esc_html(pms_process_restriction_content_message( $type, $user_id, $post_id));

    $restriction_setting = [
        'restrict_type' => $restrict_type,
        'restrict_message' => $message,
        'redirect_url' => $redirect_url
    ];
    return $restriction_setting;
}

function get_restricted_post_redirect($post_id, $type){
    $redirect_url = '';
    
    $settings = get_option('pms_content_restriction_settings', array());

    $post_redirect_url_enabled      = get_post_meta( $post_id, 'pms-content-restrict-custom-redirect-url-enabled', true );
    $post_redirect_url              = get_post_meta( $post_id, 'pms-content-restrict-custom-redirect-url', true );
    $post_non_member_redirect_url   = get_post_meta( $post_id, 'pms-content-restrict-custom-non-member-redirect-url', true );
    $redirect_url = ( ! empty( $post_redirect_url_enabled ) && ! empty( $post_redirect_url ) ? $post_redirect_url : '' );
    $non_member_redirect_url = ( ! empty( $post_redirect_url_enabled ) && ! empty( $post_non_member_redirect_url ) ? $post_non_member_redirect_url : '' );

    if(!empty($post_redirect_url) && $type == 'logged_out' ){
        $redirect_url = $post_redirect_url;
    } else if ( !empty( $non_member_redirect_url) && $type == 'non_members' ){
        $redirect_url = $non_member_redirect_url;
    }

    if( empty( $redirect_url ) ) {
        $redirect_url = ( ! empty( $settings['content_restrict_redirect_url'] ) ? $settings['content_restrict_redirect_url'] : '' );
        $non_member_redirect_url = ( ! empty( $settings['content_restrict_non_member_redirect_url'] ) ? $settings['content_restrict_non_member_redirect_url'] : '' );
        
        $redirect_url =  $type == 'logged_out' ? $redirect_url : $non_member_redirect_url;
    }
    return $redirect_url;
}

function streamit_get_movie_video_images_helper($post = null, $user_id = null)
{
	$images = array();
	$full_image = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), "full");

    if (!(empty($full_image)) && $full_image[0]) {
        $images['image'] = $full_image[0];
    } else {
        $images['image'] = '';
    }
    $images['ID'] = $post->ID;
    $images['image'] = $full_image[0];
    $images['post_title'] = get_the_title();
    $images['post_content'] = esc_html(get_the_content());
    $images['post_excerpt'] = esc_html(get_the_excerpt());
    $images['post_date'] = $post->post_date;
    $images['post_date_gmt'] = $post->post_date_gmt;
    $images['readable_date'] = get_the_date();
    $images['share_url'] = get_the_permalink();
    $images['no_of_comments'] = get_comments_number();

	return $images;
}

function streamit_post_args($params = null, $filter = null, $post_in = null)
{
    $args['post_type'] = array('movie','tv_show', 'episode' ,'video' ); //(!empty($params['post_type']) && isset($params['post_type'])) ? $params['post_type'] : 'movie';
    $args['post_status'] = 'publish';
    $args['posts_per_page'] = (!empty($params['posts_per_page']) && isset($params['posts_per_page'])) ? $params['posts_per_page'] : 20;
    $args['paged'] =  (!empty($params['paged']) && isset($params['paged'])) ? $params['paged'] : 1;
    $args['streamit_title_filter'] = ($params['search']) && !empty($params['search']) ? $params['search'] : null;

    if ($post_in) {
        $args['post__in'] = $post_in;
    }

    if ($filter === 'recent') {
        $args['order'] = 'DESC';
        $args['orderby'] = 'ID';
    }

    return $args;
}

function get_taxonomy_terms_helper( $list, $type , $taxonomy = 'cat' ) {
	$terms = array();

	foreach ( wp_get_object_terms( $list->ID, $type.'_'. $taxonomy ) as $term ) {
		$terms[] = array(
			'id'   => $term->term_id,
			'name' => $term->name,
			'slug' => $term->slug,
		);
	}

	return $terms;
}

function get_movie_show_episode_list ($id,$num_pages = '',$i='',$user_id = null) {

    $list = get_post($id);
    if( empty($list) && $list === null) {
        return [];
    }
    $post_meta     = get_post_meta($id);
    $avg_rating    = (!empty($post_meta['_masvideos_average_rating'])) ? $post_meta['_masvideos_average_rating'][0] : 0;
    $image = wp_get_attachment_image_src(get_post_thumbnail_id($id), [300, 300]);
    $temp = [
        'id'                => $list->ID,
        'title'             => get_the_title($id),
        'image'             => !empty($image) ? $image[0] : null,
        'description'       => wp_strip_all_tags(get_the_content(null,false,$id)),
        'excerpt'           => wp_strip_all_tags(get_the_excerpt($list)),
        'is_featured'       => !empty($post_meta['__featured'][0]) && $post_meta['__featured'][0] === 'yes' ? true : false,
        'post_type'         => $list->post_type,
        'likes'             => wp_ulike_get_post_likes($list->ID),
        'share_url'         => get_the_permalink($list->ID),
    ];
    $subscription_plan = isset($post_meta['pms-content-restrict-subscription-plan']) ? $post_meta['pms-content-restrict-subscription-plan'] : null;
    if ( !empty($subscription_plan) && count($subscription_plan) > 0 ) {
        $temp['restrict_subscription_plan'] = collect($subscription_plan)->map( function  ($plan) {
            $plan_data = [
                'id'    => $plan,
                'label' => get_the_title($plan),
            ];
            return $plan_data;
        });
    } else {
        $temp['restrict_subscription_plan'] = [];
    }
    $temp['user_has_pms_member'] = pms_is_member_of_plan($subscription_plan,$user_id);
    $temp['restrict_user_status'] = get_post_meta($id, 'pms-content-restrict-user-status', true);
    
    if ( $temp['restrict_user_status'] == 'loggedin'  || ( !empty($subscription_plan) && count($subscription_plan) > 0 ) ){
        $temp['restriction_setting'] = get_content_restriction_settings($list->ID,$user_id);
    } else {
        $temp['restriction_setting'] = (object) [
            'restrict_type' => ''
        ];
    }
    if($user_id != null){
        $temp['is_liked']       = streamit_user_liked_post($id,$user_id);
        $temp['is_watchlist']   = streamit_watchlist($id,$user_id);
    } else {
        $temp['is_liked']       = null;
        $temp['is_watchlist']   = null;
    }

    if( $list->post_type === 'movie' ){
        $temp['tag']        = get_taxonomy_terms_helper($list , 'movie','tag');
        $temp['genre']      = get_taxonomy_terms_helper($list , 'movie','genre');
        $temp['avg_rating'] = ($avg_rating === null ? 0 : $avg_rating );
        $temp['censor_rating']     = $post_meta['_movie_censor_rating'][0];
        $temp['views']             = isset($post_meta['post_views_count']) ? (int) $post_meta['post_views_count'][0] : 0;
    }

    if( $list->post_type === 'tv_show' ){
        $temp['tag']        = get_taxonomy_terms_helper($list , 'tv_show','tag');
        $temp['genre']      = get_taxonomy_terms_helper($list , 'tv_show','genre');
        $temp['avg_rating'] = ($avg_rating === null ? 0 : $avg_rating );
    }

    if( $list->post_type === 'video' ) {
        $temp['embed_content']     = $post_meta['_video_embed_content'][0];
        $temp['video_choice']      = $post_meta['_video_choice'][0];
        $video_file = null;
        if ( $temp['video_choice'] == 'video_file' && !empty($post_meta['_video_attachment_id']) && $post_meta['_video_attachment_id'][0] != null ) {
            $video_file = isset($post_meta['_video_attachment_id']) ? wp_get_attachment_url($post_meta['_video_attachment_id'][0]) : null;
        }
        $temp['video_file'] = $video_file;
        $temp['url_link']          = $post_meta['_video_url_link'][0];
        $temp['tag']           = get_taxonomy_terms_helper($list , 'video','tag');
        $temp['cat']           = get_taxonomy_terms_helper($list , 'video','cat');
        $temp['run_time']          = $post_meta['_video_run_time'][0];
        $temp['views']             = isset($post_meta['post_views_count']) ? (int) $post_meta['post_views_count'][0] : 0;
    }
    $temp['no_of_comments'] = (int) get_comments_number($list->ID);
    if( in_array($list->post_type , ['movie','tv_show' ,'episode']) ){
        $temp['imdb_rating'] = !empty($post_meta['name_custom_imdb_rating'][0]) ? floatval($post_meta['name_custom_imdb_rating'][0]) / 2  : 0;
    }

    return $temp;
}

function streamit_watchlist($post_id,$user_id) {

    $watchlist = get_user_meta( $user_id, '_user_watchlist', true );
    
    $watchlist_array = explode(', ', $watchlist);
    
    return in_array($post_id,$watchlist_array);
}

function streamit_user_liked_post($post_id,$user_id) {
    global $wpdb;
    $table_name = $wpdb->prefix.'ulike';

    $liked_post = $wpdb->get_row("SELECT * FROM {$table_name} WHERE `user_id`=" . $user_id . " AND `post_id` =" . $post_id . " AND `status`='like' ", OBJECT);

    return ($liked_post != null && $liked_post->status == 'like') ? 'like' : 'unlike';
}

function streamit_get_taxonomy ( $taxonomy , $terms ) {
    $data = [];
    if( count($terms) > 0 ){
        $data = [
            'taxonomy' => $taxonomy,
            'field' => 'term_id',
            'operator' => 'IN',
            'terms' => $terms,
        ];
    }
    return $data;
}
function streamit_title_filter( $where, $wp_query ){
    global $wpdb;
    if( $search_term = $wp_query->get( 'streamit_title_filter' ) ) :
        $search_term = $wpdb->esc_like( $search_term );
        $search_term = ' \'%' . $search_term . '%\'';
        $title_filter_relation = ( strtoupper( $wp_query->get( 'title_filter_relation' ) ) == 'OR' ? 'OR' : 'AND' );
        $where .= ' '.$title_filter_relation.' ' . $wpdb->posts . '.post_title LIKE ' . $search_term;
    endif;
    return $where;
}

add_filter( 'posts_where', 'streamit_title_filter', 10, 2 );

function streamit_pricing_plan($id) {
    $list = get_post($id);

    if( empty($list) && $list === null) {
        return [];
    }
    $post_meta = get_post_meta($id);

    $payment_setting = get_option('pms_payments_settings');
    
    $temp = [
        'id'                        => $list->ID,
        'title'                     => get_the_title($id),
        'description'               => wp_strip_all_tags(get_the_content(null,false,$id)),
        'excerpt'                   => wp_strip_all_tags(get_the_excerpt($list)),
        'plan_description'          => isset($post_meta['pms_subscription_plan_description'] ) ? $post_meta['pms_subscription_plan_description'][0] : null,
        'plan_duration'             => isset($post_meta['pms_subscription_plan_duration'] ) ? $post_meta['pms_subscription_plan_duration'][0] : null,
        'plan_duration_unit'        => isset($post_meta['pms_subscription_plan_duration_unit']) ? $post_meta['pms_subscription_plan_duration_unit'][0] : null,
        'plan_price'                => isset($post_meta['pms_subscription_plan_price']) ? $post_meta['pms_subscription_plan_price'][0] : null,
        'plan_sign_up_fee'          => isset($post_meta['pms_subscription_plan_sign_up_fee']) ? $post_meta['pms_subscription_plan_sign_up_fee'][0] : null,
        'plan_trial_duration'       => isset($post_meta['pms_subscription_plan_trial_duration']) ? $post_meta['pms_subscription_plan_trial_duration'][0] : null,
        'plan_trial_duration_unit'  => isset($post_meta['pms_subscription_plan_trial_duration_unit']) ? $post_meta['pms_subscription_plan_trial_duration_unit'][0] : null,
        'pms_price_format'          => pms_format_price($post_meta['pms_subscription_plan_price'][0] ,$payment_setting['currency'], $payment_setting['currency_position']),
        'plan_top_parent'           => isset($post_meta['pms_subscription_plan_top_parent']) ? $post_meta['pms_subscription_plan_top_parent'][0] : null,
    ];
    $plan_category = pricing_plan_detail($list->ID);
    $temp['plan_category'] = isset($plan_category) && !empty($plan_category) ? $plan_category->plan_category : [];

    return $temp;

}

function pricing_plan_detail($id)
{
    $args = array(
        'post_type'     => 'pricing',
        'post_status'   => 'publish',
        'meta_query'    => array(
            array (
                'key' => 'name_paid_sub_id',
                'value'   => $id
                )
            )
        );
    $my_query = new WP_Query( $args );
    $post_data = (object) [];
    if( $my_query->have_posts() ) {
        while( $my_query->have_posts() ) {
            $my_query->the_post();
            $post_data = get_post(get_the_ID());
            $post_data->plan_category = streamit_get_custom_taxonomy('pricing_categories',get_the_ID());
        }
    }

    return $post_data;
}

function streamit_user_plans($user_id)
{
    $plans = pms_get_member_subscriptions( array( 'user_id' => $user_id ) );

    $plan_detail = [];
    if( count($plans) > 0 ) {

        foreach( $plans as $subscription ){
            $subscription_statuses = pms_get_member_subscription_statuses();

            $subscription_plan = pms_get_subscription_plan( $subscription->subscription_plan_id );
            $plan_detail['subscriptions'][] = [
                "subscription_plan_id"  => $subscription->subscription_plan_id ,
                "start_date"            => ( ! empty( $subscription->start_date ) ? ucfirst( date_i18n( get_option('date_format'), strtotime( $subscription->start_date ) ) ) : '' ),
                "expiration_date"       => ( ! empty( $subscription->expiration_date ) ? ucfirst( date_i18n( get_option('date_format'), strtotime( $subscription->expiration_date ) ) ) : __( 'Unlimited', 'paid-member-subscriptions' ) ),
                "status"                => ( ! empty( $subscription->status ) ? $subscription->status : '' ),
                "status_label"          => ( ! empty( $subscription_statuses[$subscription->status] ) ? $subscription_statuses[$subscription->status] : '' ),
                "trail_status"          => ( $subscription->is_trial_period() ? ' (' . __( 'Trial', 'paid-member-subscriptions' ) . ')' : '' ),
                "subscription_plan_name"=> ( ! empty( $subscription_plan->name ) ? $subscription_plan->name : '' ),
                "billing_amount"        => pms_format_price( $subscription->billing_amount, pms_get_active_currency() ),
                "trial_end"             => ucfirst( date_i18n( get_option('date_format'), strtotime( $subscription->trial_end ) ) )
            ];
        }
    }
    
    return (object) $plan_detail;
}

function streamit_get_custom_taxonomy($taxo = '',$post_id)
{
    if (empty($taxo)) {
        return;
    }

    $show_count = 0; // 1 for yes, 0 for no
    $pad_counts = 0; // 1 for yes, 0 for no
    $hierarchical = 1; // 1 for yes, 0 for no
    $title = '';
    $empty = 0;
    $array = array();
    $args = array(
        'taxonomy' => $taxo,
        'show_count' => $show_count,
        'pad_counts' => $pad_counts,
        'hierarchical' => $hierarchical,
        'hide_empty' => false,
        'parent' => 0
    );
    $wp_object = get_categories($args);

    if (!empty($wp_object)) {
        foreach ($wp_object as $val) {
            $array[] = [
                'type'  => get_term_meta($val->term_id, 'name_cat_type', true),
               'slug'   => $val->slug,
               'label'  => $val->name,
               'value'  => get_post_meta($post_id, $val->slug, true),
            ];
        }
    }

    return $array;
}

function get_cast_crew_helper($post_id, $type = '_cast'){
    $data = get_post_meta( $post_id , $type, true);
    $name = "";
    if(!empty($data)) {
        $data = collect($data)->map(function ($cast) {
            return get_the_title($cast['id']);
        })->toArray();

        $data = implode(',',$data);
    }else{
        $data = "";
    }
    return $data;
}

function get_content_restriction_settings($post_id = null,$user_id = null)
{
    $settings = get_option('pms_content_restriction_settings');
    $post_subscription_plans  = get_post_meta( $post_id, 'pms-content-restrict-subscription-plan' );
    $restrict_user_status = get_post_meta($post_id, 'pms-content-restrict-user-status', true);

    $post_restriction_type = get_post_meta( $post_id, 'pms-content-restrict-type', true );
    $is_plan = empty( $post_subscription_plans ) ? true : false;
    if ( isset( $user_id ) && !$is_plan ){
        if( pms_is_member( $user_id, $post_subscription_plans ) ){
            return (object) array();
        }
    }
    
    if( $post_restriction_type != 'default' ) {
        $settings['content_restrict_type'] = $post_restriction_type;
    }

    $restriction['restrict_type'] = $settings['content_restrict_type'];

    if( $settings['content_restrict_type'] == "template" )
    {
        $restriction['restrict_type'] = 'message';
        if($user_id == null){
            $restriction['restrict_message'] = $settings['logged_out'];
        }else{
            $restriction['restrict_message'] = $settings['non_members'];
        }
        return $restriction;
    }
    
    if( ($restrict_user_status == 'loggedin') && ( $settings['content_restrict_type'] == 'message') ){
        if (isset( $user_id ) && !$is_plan){
            $restriction['restrict_message'] = esc_html(pms_get_restricted_post_message($post_id));
        }elseif( $user_id == null ){
            $restriction['restrict_message'] = esc_html(pms_get_restricted_post_message($post_id));
        }else{
            return (object) array();
        }
    } else {
        $restriction['restrict_message'] = '';
    }

    if ($settings['content_restrict_type'] == 'redirect' ){
        $redirect_url = '';
        
        $post_redirect_url_enabled      = get_post_meta( $post_id, 'pms-content-restrict-custom-redirect-url-enabled', true );
        $post_redirect_url              = get_post_meta( $post_id, 'pms-content-restrict-custom-redirect-url', true );
        $post_non_member_redirect_url   = get_post_meta( $post_id, 'pms-content-restrict-custom-non-member-redirect-url', true );

        $redirect_url = ( ! empty( $post_redirect_url_enabled ) && ! empty( $post_redirect_url ) ? $post_redirect_url : '' );
        $non_member_redirect_url = ( ! empty( $post_redirect_url_enabled ) && ! empty( $post_non_member_redirect_url ) ? $post_non_member_redirect_url : '' );

        if ( !empty( $non_member_redirect_url) ){
            if ( isset( $user_id ) && isset( $post_subscription_plans ) && !pms_is_member( $user_id, $post_subscription_plans ) ){
                $redirect_url = $non_member_redirect_url;
            }
        }
        if( empty( $redirect_url ) ) {

            $redirect_url = ( ! empty( $settings['content_restrict_redirect_url'] ) ? $settings['content_restrict_redirect_url'] : '' );
            $non_member_redirect_url = ( ! empty( $settings['content_restrict_non_member_redirect_url'] ) ? $settings['content_restrict_non_member_redirect_url'] : '' );
            if ( !empty( $non_member_redirect_url ) ){
                if ( isset( $user_id ) && isset( $post_subscription_plans ) && !pms_is_member( get_current_user_id(), $post_subscription_plans ) ){
                    $redirect_url = $non_member_redirect_url;
                }
            }
        }
        $restriction['redirect_url'] = $redirect_url;
    }
    return $restriction;
}

function streamit_get_most_liked($post_type = '', $args = array(), $return = '')
{
    $liked = wp_ulike_get_most_liked_posts(10, $post_type, 'post', 'all', 'like');
    if ($liked) {
        foreach ($liked as $post) {
            $most_liked_ids[] = $post->ID;
        }
        return $most_liked_ids;
    }
}

function streamit_get_options(){
    $streamit_options = get_option('streamit_options');
    $page_link = [];
    $page_link['streamit_movie_display_comment'] = '';
    $page_link['streamit_tvshow_display_comment'] = '';
    $page_link['streamit_episode_display_comment'] = '';
    $page_link['streamit_video_display_comment'] = '';

    if( get_option('template') == 'streamit' ){
        if (isset($streamit_options['streamit_signup_link']) && $streamit_options['streamit_signup_link'] != null ){
            $page_link['register_page'] = get_permalink($streamit_options['streamit_signup_link']);
        }
        if (isset($streamit_options['streamit_profile_link']) && $streamit_options['streamit_profile_link'] != null){
            $page_link['account_page'] = get_permalink($streamit_options['streamit_profile_link']);
        }
        if (isset($streamit_options['streamit_signin_link']) && $streamit_options['streamit_signin_link'] != null ){
            $page_link['login_page'] = get_permalink($streamit_options['streamit_signin_link']);
        }

        $page_link['streamit_movie_display_comment'] = $streamit_options['streamit_movie_display_comment'];
        $page_link['streamit_tvshow_display_comment'] = $streamit_options['streamit_tvshow_display_comment'];
        $page_link['streamit_episode_display_comment'] = $streamit_options['streamit_episode_display_comment'];
        $page_link['streamit_video_display_comment'] = $streamit_options['streamit_video_display_comment'];
    }
    $pms_settings = get_option( 'pms_general_settings' );
    // if(empty($page_link) ){
        if(!isset($page_link['register_page'])){
           $page_link['register_page'] = isset($pms_settings) && $pms_settings['register_page'] != -1 ? get_permalink($pms_settings['register_page']) : null;
        }
        if(!isset($page_link['account_page'])){
            $page_link['account_page'] = isset($pms_settings) && $pms_settings['account_page'] != -1 ? get_permalink($pms_settings['account_page']) : null;
        }

        if(!isset($page_link['login_page'])){
            $page_link['login_page'] = isset($pms_settings) && $pms_settings['login_page'] != -1 ? get_permalink($pms_settings['login_page']) : null;
        }
    // }
    return $page_link;
}

function user_posts_view_count($post_id)
{
    global $wpdb;
    // $post_id = get_the_ID();

    $post_type = get_post_type($post_id);
    $ipaddress = $_SERVER['REMOTE_ADDR'] ;
    
    $table_name = $wpdb->prefix . 'streamit_postview';
    
    $already_exist = $wpdb->get_row("SELECT * FROM $table_name WHERE ip_address = '{$ipaddress}' AND post_id = {$post_id} ",OBJECT);
    
    if ( gettype($already_exist) !== 'object') {
        $wpdb->insert($table_name, array(
            'ip_address' => $ipaddress,
            'post_id' => $post_id
        ));

        set_postview($post_id);
        if(in_array($post_type,['tv_show','episode']))
        {
            $key = 'tv_show_views_count';

            $tv_show_id = get_post_meta($post_id,'_tv_show_id',true);
            $seasons = get_post_meta($tv_show_id,'_seasons');
            
            $ep_id = array_column($seasons[0],'episodes');
            $id = call_user_func_array('array_merge',$ep_id);

            $count = count($id);
            $sum = 0;
            $args = array(
                'post_type' => 'episode',
                'post__in' => $id,
            );

            $query = new WP_Query($args);
            if ( $query->have_posts() ) {
                while( $query->have_posts() ) {
                    $query->the_post();
                    $view = get_post_meta( get_the_ID(), 'post_views_count', true );

                    if($view)
                    {
                        $sum += $view;
                    }
                }
            }

            update_post_meta( $tv_show_id, $key, ceil($sum/$count) );
        }
    }
}

function set_postview($post_id) {
    $key = 'post_views_count';
    
    $count = (int) get_post_meta( $post_id, $key, true );
    $count++;
    update_post_meta( $post_id, $key, $count );
}


function streamit_cast_detail_helper($post_id,$cast_id = null){
    $cast = get_post_meta($post_id , '_cast',true);

    if(!empty($cast) && count($cast) > 0){
        $cast = collect($cast)->map(function ($cast) {
            $cast_image = wp_get_attachment_image_src(get_post_thumbnail_id($cast['id']), [300, 300]);
            
            $cast['image'] = !empty($cast_image) ? $cast_image[0] : null;            
            $cast['name'] = get_the_title($cast['id']);
            return $cast;
        });

        if($cast_id != null ){
            $cast = $cast->where('id',$cast_id)->pluck('character')->implode(',');
        }
    } else {
        $cast = [];
    }

    return $cast;
}

function streamit_movie_show_cast_detail_helper($id,$cast_id){
    
    $list = get_post($id);

    if( empty($list) && $list === null) {
        return [];
    }
    $id = $list->ID;
    $post_meta = get_post_meta($id);
    
    $image = wp_get_attachment_image_src(get_post_thumbnail_id($id), [300, 300]);
    $character_name = streamit_cast_detail_helper($id, $cast_id);
    $temp = [
        'id'                => $id,
        'title'             => get_the_title($id),
        'image'             => !empty($image) ? $image[0] : null,
        'post_type'         => $list->post_type,
        'character_name'    => is_array($character_name) ? "" : $character_name,
        'share_url'         => get_the_permalink($id),
    ];

    if($list->post_type == 'tv_show'){
        $tv_show_season = get_post_meta($id, '_seasons',true);    
        $temp['total_seasons'] = 0;
        $year = null;
        if ( !empty($tv_show_season)) {
            $temp['total_seasons'] = count($tv_show_season);
            $year = collect($tv_show_season)->map(function ($tv_show_season) use($year) {
                return $tv_show_season;
            })->pluck('year')->implode('-');
        }
        $temp['release_year'] = $year;
    }else{
        $release_year = get_post_meta($id, '_movie_release_date' , true);
        if (!empty($release_year)) {
            $temp['release_year'] = date('Y', $release_year);
        }
    }
    return $temp;
}

function streamit_source_list($post_id){
    $source = get_post_meta($post_id , '_sources',true);

    if(!empty($source) && count($source) > 0){
        $source = collect($source)->map(function ($source) {
            return $source;
        });
    } else {
        $source = [];
    }

    return $source;
}
