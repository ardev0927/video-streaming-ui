<?php


namespace Includes\baseClasses;

class STDeactivate {

	public static function init () {

	}
}