<?php

namespace Includes\baseClasses;
use WP_Session_Tokens;
use WP_Session;
class STActivate extends STBase {

	public static function activate() {
		( new STGetDependency( 'jwt-authentication-for-wp-rest-api' ) )->getPlugin();
		( new STGetDependency( 'masvideos' ) )->getPlugin();
		( new STGetDependency( 'wp-ulike' ) )->getPlugin();
		( new STGetDependency( 'advanced-custom-fields' ) )->getPlugin();
		( new STGetDependency( 'paid-member-subscriptions' ) )->getPlugin();
		( new STGetDependency( 'onesignal-free-web-push-notifications' ) )->getPlugin();
	}

	public function init() {

		if ( isset( $_REQUEST['page'] ) && strpos($_REQUEST['page'], "streamit-app-configuration") !== false ) {
			// Enqueue Admin-side assets...
            add_action( 'admin_enqueue_scripts', array( $this, 'enqueueStyles' ) );
            add_action( 'admin_enqueue_scripts', array( $this, 'enqueueScripts' ) );

        }

		// API handle
		( new STApiHandler() )->init();

		// Action to add option in the sidebar...
		add_action( 'admin_menu', array( $this, 'adminMenu' ) );

		// Action to change authentication api response ...
		add_filter( 'jwt_auth_token_before_dispatch', array($this, 'jwtAuthenticationResponse'), 10, 2 );


	}

	public function adminMenu() {
		$user = wp_get_current_user();
		$roles = ( array ) $user->roles;
	   	if( in_array('administrator' , $roles) ){
			add_menu_page( __( 'App Configuration' ), 'App Configuration', 'read', 'streamit-app-configuration',  [
				$this,
				'adminDashboard'
			], $this->plugin_url . 'assets/images/sidebar-icon.png', 99 );
		}
	}

    public function adminDashboard() {
        include( STREAMIT_API_DIR . 'resources/views/st_admin_panel.php' );
    }

	public function adminDashboardHome() {
		include( STREAMIT_API_DIR . 'resources/views/st_admin_movie.php' );
	}

    public function adminDashboardMovie() {
        include( STREAMIT_API_DIR . 'resources/views/st_admin_movie.php' );
    }

    public function adminDashboardTVShow() {
        include( STREAMIT_API_DIR . 'resources/views/st_admin_tv_show.php' );
    }

	public function enqueueStyles() {
        wp_enqueue_style( 'st_bootstrap_css', STREAMIT_API_DIR_URI . 'assets/css/bootstrap.min.css' );
        // wp_enqueue_style( 'st_app_min_style', STREAMIT_API_DIR_URI . 'assets/css/app.min.css' );
        wp_enqueue_style( 'st_font_awesome', STREAMIT_API_DIR_URI . 'assets/css/font-awesome.min.css' );
        wp_enqueue_style('st_bootstrap_select', STREAMIT_API_DIR_URI . 'admin/css/bootstrap-select.css');
        wp_enqueue_style('st_custom', STREAMIT_API_DIR_URI . 'assets/css/custom.css');
        wp_enqueue_style('st_admin_panel_css', STREAMIT_API_DIR_URI . 'admin/css/streamit-api-admin.css');
    }

	public function enqueueScripts() {
        wp_enqueue_script( 'st_bootstrap_js', STREAMIT_API_DIR_URI . 'assets/js/bootstrap.min.js', [ 'jquery' ], false, true );
        wp_enqueue_script( 'st_js_bundle', STREAMIT_API_DIR_URI . 'assets/js/app.min.js', [ 'jquery' ], false, true );
        wp_enqueue_script( 'st_js_popper', STREAMIT_API_DIR_URI . 'admin/js/popper.min.js', [ 'jquery' ], false, false );
        wp_enqueue_script( 'st_bootstrap_select', STREAMIT_API_DIR_URI . 'admin/js/bootstrap-select.js', [ 'jquery' ], false, true );
        wp_enqueue_script('st_sweetalert', STREAMIT_API_DIR_URI . 'admin/js/sweetalert.min.js', ['jquery'], false, true);
        wp_enqueue_script('st_custom', STREAMIT_API_DIR_URI . 'assets/js/custom.js', ['jquery'], false, true);
        wp_localize_script('st_custom', 'st_localize', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('get_st_admin_settings')
        ));

		wp_localize_script( 'st_js_bundle', 'request_data', array(
			'ajaxurl'         => admin_url( 'admin-ajax.php' ),
			'nonce'           => wp_create_nonce( 'ajax_post' ),
			'streamitPluginURL' => STREAMIT_API_DIR_URI,
		) );

		wp_enqueue_script( 'st_js_bundle' );
	}

	public function jwtAuthenticationResponse( $data, $user ) {

		$img       = get_user_meta( $user->ID, 'streamit_profile_image' ,true );
		$user_info = get_userdata( $user->ID );

		$data['first_name'] = $user_info->first_name;
		$data['last_name']  = $user_info->last_name;
		$data['user_id']    = $user->ID;
		$data['username']   = $user->user_login;
		$data['user_email'] = $user->user_email;
		$data['profile_image'] = $img;
		$data['streamit_profile_image'] = $img;

		$data['plan'] = (object) streamit_user_plans($user->ID);

		$pms_settings = get_option( 'pms_general_settings' );
		if ( isset( $pms_settings['prevent_account_sharing'] ) && !empty( $pms_settings['prevent_account_sharing'] ) ) {
			update_user_meta($user->ID,'session_tokens',$data['token']);
		}
		return $data;
	}

}


