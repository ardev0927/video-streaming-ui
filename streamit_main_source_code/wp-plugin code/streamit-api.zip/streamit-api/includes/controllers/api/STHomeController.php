<?php

namespace Includes\Controllers\Api;

use Includes\baseClasses\STBase;
use WP_REST_Response;
use WP_REST_Server;

class STHomeController extends STBase {

	public $module = 'videos';

	public $nameSpace;

	function __construct() {

		$this->nameSpace = STREAMIT_API_NAMESPACE;

		add_action( 'rest_api_init', function () {

			register_rest_route( $this->nameSpace . '/api/v1/' . $this->module, '/get-videos', array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => [ $this, 'getVideos' ],
				'permission_callback' => '__return_true'
			) );

		} );
	}

	public function getVideos($request) {

		$data = stValidationToken();

		if (!$data['status']) {
			return new WP_REST_Response($data);
		}

		return new WP_REST_Response( [
			'status'  => true,
			'message' => "Working",
			'data' => $data
		] );
	}
}