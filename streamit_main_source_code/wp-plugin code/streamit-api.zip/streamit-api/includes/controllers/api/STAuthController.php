<?php

namespace Includes\Controllers\Api;

use Includes\baseClasses\STBase;
use WP_Error;
use WP_REST_Response;
use WP_REST_Server;

class STAuthController extends STBase {

	public $module = 'auth';

	public $nameSpace;

	function __construct() {

		$this->nameSpace = STREAMIT_API_NAMESPACE;

		add_action( 'rest_api_init', function () {

			register_rest_route( $this->nameSpace . '/api/v1/' . $this->module, '/registration', array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => [ $this, 'createUser' ],
				'permission_callback' => '__return_true',
			) );

			register_rest_route( $this->nameSpace . '/api/v1/' . $this->module, '/token-validate', array(
				'methods'             => WP_REST_Server::ALLMETHODS,
				'callback'            => [ $this, 'validateToken' ],
				'permission_callback' => '__return_true',
			) );
		} );
	}

	public function createUser($request) {

		$reqArr = $request->get_params();

		$validation = stValidateRequest([
			'user_login' => 'required',
			'first_name' => 'required',
			'last_name' => 'required',
			'user_email' => 'email|required',
			'user_pass' => 'required',
		], $reqArr);

		$error = new WP_Error();
		if (count($validation)) {
			
			return comman_message_response($validation[0] , 400);

			// $error->add(400, __($validation[0], 'wp-rest-user'), array('status' => 400));
			// return $error;
		}

		$res = wp_insert_user($reqArr);

		if (isset($res->errors)) {
			return comman_message_response(stGetErrorMessage($res),400);
			// $error->add(400, __(stGetErrorMessage($res), 'wp-rest-user'), array('status' => 400));
			// return $error;
		}

		wp_update_user([
			'ID' => $res,
			'first_name' => $reqArr['first_name'],
			'last_name' => $reqArr['last_name']
		]);
		
		return comman_message_response(__('User Register succesfully'));
	}

	public function validateToken($request)
	{
		$data = stValidationToken($request);

		return comman_custom_response($data);
	}
}