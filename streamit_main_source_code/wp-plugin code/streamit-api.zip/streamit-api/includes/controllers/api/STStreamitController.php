<?php

namespace Includes\Controllers\Api;

use Includes\baseClasses\STBase;
use WP_REST_Response;
use WP_REST_Server;
use WP_Query;
use WP_Term_Query;

class STStreamitController extends STBase {

	public $module = 'streamit';

	public $nameSpace;

	function __construct() {

		$this->nameSpace = STREAMIT_API_NAMESPACE;

		add_action( 'rest_api_init', function () {

			register_rest_route( $this->nameSpace . '/api/v1/' . $this->module, '/search-list', array(
				'methods'             => WP_REST_Server::ALLMETHODS,
				'callback'            => [ $this, 'streamit_search_list' ],
				'permission_callback' => '__return_true'
			) );

			register_rest_route( $this->nameSpace . '/api/v1/' . $this->module, '/like-movie-show', array(
				'methods'             => WP_REST_Server::ALLMETHODS,
				'callback'            => [ $this, 'streamit_like_dislike' ],
				'permission_callback' => '__return_true'
			) );

			register_rest_route( $this->nameSpace . '/api/v1/' . $this->module, '/add-remove-watchlist', array(
				'methods'             => WP_REST_Server::ALLMETHODS,
				'callback'            => [ $this, 'streamit_add_remove_watchlist' ],
				'permission_callback' => '__return_true'
			) );

			register_rest_route( $this->nameSpace . '/api/v1/' . $this->module, '/change-password', array(
				'methods'             => WP_REST_Server::ALLMETHODS,
				'callback'            => [ $this, 'streamit_change_password' ],
				'permission_callback' => '__return_true'
			) );

			register_rest_route( $this->nameSpace . '/api/v1/' . $this->module, '/forgot-password', array(
				'methods'             => WP_REST_Server::ALLMETHODS,
				'callback'            => [ $this, 'streamit_forgot_password' ],
				'permission_callback' => '__return_true'
			) );

			register_rest_route( $this->nameSpace . '/api/v1/' . $this->module, '/get-watchlist', array(
				'methods'             => WP_REST_Server::ALLMETHODS,
				'callback'            => [ $this, 'streamit_get_watchlist' ],
				'permission_callback' => '__return_true'
			) );

			register_rest_route( $this->nameSpace . '/api/v1/' . $this->module, '/update-profile', array(
				'methods'             => WP_REST_Server::ALLMETHODS,
				'callback'            => [ $this, 'streamit_update_profile' ],
				'permission_callback' => '__return_true'
			) );

			register_rest_route( $this->nameSpace . '/api/v2/' . $this->module, '/update-profile', array(
				'methods'             => WP_REST_Server::ALLMETHODS,
				'callback'            => [ $this, 'streamit_v2_update_profile' ],
				'permission_callback' => '__return_true'
			) );

			register_rest_route( $this->nameSpace . '/api/v1/' . $this->module, '/get-dashboard', array(
				'methods'             => WP_REST_Server::ALLMETHODS,
				'callback'            => [ $this, 'streamit_get_dashboard' ],
				'permission_callback' => '__return_true'
			) );

			register_rest_route( $this->nameSpace . '/api/v1/' . $this->module, '/slider-view-all', array(
				'methods'             => WP_REST_Server::ALLMETHODS,
				'callback'            => [ $this, 'streamit_slider_view_all' ],
				'permission_callback' => '__return_true'
			) );

			register_rest_route( $this->nameSpace . '/api/v1/' . $this->module, '/view-profile', array(
				'methods'             => WP_REST_Server::ALLMETHODS,
				'callback'            => [ $this, 'streamit_view_profile' ],
				'permission_callback' => '__return_true',
			) );

			register_rest_route( $this->nameSpace . '/api/v1/' . $this->module, '/get-genre-by-type', array(
				'methods'             => WP_REST_Server::ALLMETHODS,
				'callback'            => [ $this, 'streamit_get_genre' ],
				'permission_callback' => '__return_true'
			) );

			register_rest_route( $this->nameSpace . '/api/v1/' . $this->module, '/get-list-by-genre', array(
				'methods'             => WP_REST_Server::ALLMETHODS,
				'callback'            => [ $this, 'streamit_get_list_by_genre' ],
				'permission_callback' => '__return_true'
			) );
			
			register_rest_route( $this->nameSpace . '/api/v1/' . $this->module, '/	', array(
				'methods'             => WP_REST_Server::ALLMETHODS,
				'callback'            => [ $this, 'streamit_user_has_access' ],
				'permission_callback' => '__return_true'
			) );
			register_rest_route( $this->nameSpace . '/api/v1/' . $this->module, '/delete-account', array(
				'methods'             => WP_REST_Server::ALLMETHODS,
				'callback'            => [ $this, 'streamit_delete_user_account' ],
				'permission_callback' => '__return_true'
			) );
		} );
	}

	public function streamit_user_has_access($request)
	{
		$parameters = $request->get_params();
		$id = $parameters['id'];

		$args = [
			'post__in' => [$id],
			'post_type' => array('movie','tv_show', 'episode' ,'video' ),
			'post_status' => 'publish',
		];

        $wp_query = new WP_Query($args);
        $response_data = $wp_query->post;
		$response = [];
        $data = stValidationToken($request);

		$user_id = null;
		if ($data['status']) {
			$user_id = $data['user_id'];
        }elseif(!$data['status'] && $data['status_code'] == 401) {
            return comman_custom_response($data,$data['status_code']);
        }
        if (isset($response_data) && $response_data !== null && $response_data !== '') {
            $response = streamit_movie_video_detail_helper($id,$user_id);
        }
		return comman_custom_response($response);
	}
	public function streamit_search_list($request) {

		$parameters = $request->get_params();
	
		$array = array();
		$masterarray = array();
	
		$args = array();
		
		$parameters['post_type'] = [ 'movie','tv_show', 'episode', 'video' ];
		
		$data = stValidationToken($request);

		$user_id = null;
		if ($data['status']) {
			$user_id = $data['user_id'];
        }elseif(!$data['status'] && $data['status_code'] == 401) {
            return comman_custom_response($data,$data['status_code']);
        }
		$args = streamit_post_args($parameters);
	
		$wp_query = new WP_Query($args);
	
		$total = $wp_query->found_posts;
		$num_pages = 1;
		$num_pages = $wp_query->max_num_pages;
	
		$i = 1;
		while ($wp_query->have_posts()) {
			$wp_query->the_post();
			$array = streamit_movie_video_detail_helper(get_the_ID(), $user_id);
			array_push($masterarray, $array);
			$i++;
		}
	
		return comman_list_response($masterarray);  
	
	}

	public function streamit_like_dislike($request) {
		global $wpdb;
		$table_name = $wpdb->prefix.'ulike';
		$table_ulike_meta = $wpdb->prefix.'ulike_meta';
		$data = stValidationToken($request);

		if ($data['status']) {
			$user_id = $data['user_id'];
        }elseif(!$data['status'] && $data['status_code'] == 401) {
            return comman_custom_response($data,$data['status_code']);
        }

		$parameters = $request->get_params();
		
		$post_id = $parameters['post_id'];
		$user_id = $data['user_id'];
	
		$post = get_post($post_id);
	
		if($post == null){
			return comman_message_response( __('Not found') , 422 );
		}
	
		$post_status = $wpdb->get_row("SELECT * FROM {$table_name} WHERE `user_id`=" . $user_id . " AND `post_id` =" . $post_id . "", OBJECT);
	
		$ulike_post_meta = $wpdb->get_row("SELECT * FROM {$table_ulike_meta} WHERE `item_id`=" . $post_id . " AND `meta_key`='count_distinct_like'", OBJECT);
		
		if ( $ulike_post_meta == null ) {
			$wpdb->insert( $table_ulike_meta , array(
				"item_id"		=> $post_id,
				"meta_group" 	=> 'post',
				"meta_key"      => 'count_distinct_like',
				"meta_value"	=> 0
			));
		}
		$message = null;
		$isLiked = null;
		if($post_status != null) {

			if($post_status->status == 'like'){
				$wpdb->query("UPDATE $table_ulike_meta SET `meta_value`= meta_value - 1 WHERE `item_id` =" . $post_id . " AND  `meta_key`='count_distinct_like' AND `meta_group` = 'post' ");
				$wpdb->query("UPDATE $table_name SET `status`='unlike' WHERE `user_id`=" . $user_id . " AND `post_id` =" . $post_id . "");
				$isLiked = false;
				$message = __("You unliked this");
			}

			if($post_status->status == 'unlike'){
				$wpdb->query("UPDATE $table_ulike_meta SET `meta_value`= meta_value + 1 WHERE `item_id` =" . $post_id . " AND  `meta_key`='count_distinct_like' AND `meta_group` = 'post' ");
				$wpdb->query("UPDATE $table_name SET `status`='like' WHERE `user_id`=" . $user_id . " AND `post_id` =" . $post_id . "");
				$isLiked = true;
				$message = __("You liked this");
			}
		}else{
			$wpdb->insert( $table_name , array(
				'user_id'   => $user_id,
				'post_id'   => $post_id,
				'date_time'	=> wp_date('Y-m-d H:i:s'),
				'status'    => 'like'
			)
			);
			$wpdb->query("UPDATE $table_ulike_meta SET `meta_value`= meta_value + 1 WHERE `item_id` =" . $post_id . " AND  `meta_key`='count_distinct_like' AND `meta_group` = 'post' ");
			$isLiked = true;
			$message = __("You liked this");
		}
		$resArray = array('is_added' => $isLiked, 'message' => $message);
		return comman_custom_response( $resArray );
	}

	public function streamit_add_remove_watchlist($request) {

		$data = stValidationToken($request);

		if ($data['status']) {
			$user_id = $data['user_id'];
        }elseif(!$data['status'] && $data['status_code'] == 401) {
            return comman_custom_response($data,$data['status_code']);
        }

		$parameters = $request->get_params();
		
		$post_id = $parameters['post_id'];
		$user_id = $data['user_id'];
	
	
		$post = get_post($post_id);
	
		if($post == null){
			return comman_message_response( __('Not found') , 422 );
		}
	
		$watch_list = streamit_watchlist($post_id ,$user_id);
	
		$post_watchlist = get_user_meta( $user_id, '_user_watchlist', true );
	
		$watchlist_array = explode(', ', $post_watchlist);
		$isAdded= false;
	
		if(!$watch_list){
			// Check if the likers metabox already has a value to determine if the new entry has to be prefixed with a comma or not
	
			if(!empty($post_watchlist)){
				$newvalue = $post_watchlist .', '. $post_id;
			}else{
				$newvalue = $post_id;
			}
	
			update_user_meta($user_id, '_user_watchlist', $newvalue, $post_watchlist);
			$message  = __("Added into watchlist");
	
			$isAdded = true;
		} else {
			$key = array_search($post_id, $watchlist_array);

			unset($watchlist_array[$key]);
			
			update_user_meta($user_id, '_user_watchlist', implode(", ", $watchlist_array), $post_watchlist);
	
			$message  = __("Remove from watchlist");
		
		}    
	
		$resArray = array('is_added' => $isAdded, 'message' => $message);
		return comman_custom_response($resArray);
	}

	public function streamit_change_password($request) {

		$data = stValidationToken($request);

		if ($data['status']) {
			$user_id = $data['user_id'];
        }elseif(!$data['status'] && $data['status_code'] == 401) {
            return comman_custom_response($data,$data['status_code']);
        }

		$parameters = $request->get_params();

		$userdata = get_user_by('ID', $data['user_id']);
		
		if ($userdata == null) {
			
			if ($userdata == null) {
				$message = __('User not found');
				return comman_message_response($message,422);
			}
		}

		$status_code = 200;

		if (wp_check_password($parameters['old_password'], $userdata->data->user_pass)){
			wp_set_password($parameters['new_password'], $userdata->ID);
			$message = __("Password has been changed successfully");
		}else {
			$status_code = 422;
			$message = __("Old password is invalid");
		}
		return comman_message_response($message,$status_code);
	}

	public function streamit_forgot_password($request) {
		$parameters = $request->get_params();
		$email = $parameters['email'];
		
		$user = get_user_by('email', $email);
		$message = null;
		$status_code = null;
		
		if($user) {      

			$title = 'New Password';
            $password = stGenerateString();
            $message = '<label><b>Hello,</b></label>';
            $message.= '<p>Your recently requested to reset your password. Here is the new password for your App</p>';
            $message.='<p><b>New Password </b> : '.$password.'</p>';
            $message.='<p>Thanks,</p>';

            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
			$is_sent_wp_mail = wp_mail($email,$title,$message,$headers);

            if($is_sent_wp_mail) {
				wp_set_password( $password, $user->ID);
				$message = __('Password has been sent successfully to your email address.');
				$status_code = 200;
			} elseif (mail( $email, $title, $message, $headers )) {
				wp_set_password( $password, $user->ID);
				$message = __('Password has been sent successfully to your email address.');
				$status_code = 200;
			} else {
				$message = __('Email not sent');
				$status_code = 422;
			}
		} else {
			$message = __('User not found with this email address');
			$status_code = 422;
		}
		return comman_message_response($message,$status_code);
	}

	public function streamit_get_watchlist($request) {
		$data = stValidationToken($request);

		if ($data['status']) {
			$user_id = $data['user_id'];
        }elseif(!$data['status'] && $data['status_code'] == 401) {
            return comman_custom_response($data,$data['status_code']);
        }

		$parameters = $request->get_params();
		$userdata = get_user_by('ID', $data['user_id']);
		
		if ($userdata == null) {
			
			if ($userdata == null) {
				$message = __('User not found');
				return comman_message_response($message,422);
			}
		}

		$post_watchlist = get_user_meta( $data['user_id'] , '_user_watchlist', true );

		$response = [];
		if(!empty($post_watchlist) && $post_watchlist != null) {

			$watchlist_array = explode(', ', $post_watchlist);

			$args = array(
				'post_type'         => ['movie', 'tv_show', 'video'],
				'post_status'       => 'publish',
				'post__in'          => $watchlist_array
			);
			
			$wp_query = new \WP_Query($args);
			if ( $wp_query->have_posts() ) {
				while ( $wp_query->have_posts() ) {
					$wp_query->the_post();
					array_push( $response, streamit_movie_video_detail_helper( get_the_ID(), $user_id ) );
				}
			}
		/*
			if(count($watchlist_array) > 0) {
				foreach( $watchlist_array as $post ) {
					$response[] = streamit_movie_video_detail_helper($post,$data['user_id']);
				}
			}
		*/
		}

		return comman_list_response($response);
	}

	public function streamit_update_profile($request) {
		$data = stValidationToken($request);

		if ($data['status']) {
			$user_id = $data['user_id'];
        }elseif(!$data['status'] && $data['status_code'] == 401) {
            return comman_custom_response($data,$data['status_code']);
        }

		$parameters = $request->get_params();
		$userdata = get_user_by('ID', $data['user_id']);
		
		if ($userdata == null) {
			
			if ($userdata == null) {
				$message = __('User not found');
				return comman_message_response($message,422);
			}
		}
		$message = __("Profile has been updated successfully");
		$data = array();
		wp_update_user([
			'ID' => $userdata->ID,
			'first_name' => $parameters['first_name'],
			'last_name' => $parameters['last_name']
		]);
		
		$data = [
			'first_name' => get_user_meta($userdata->ID , 'first_name' ,true),
			'last_name' => get_user_meta($userdata->ID , 'last_name' ,true),
			'username' => $userdata->user_login,
			'user_email' => $userdata->user_email,
		];
		if( isset($parameters['profile_image']) && $parameters['profile_image'] != null ){

			$profile_image = $parameters['profile_image']; 
			$type      = explode(';', $profile_image)[0];
			$extension = explode('/', $type)[1];

			// Upload dir.
			$upload_dir  = wp_upload_dir();
			$upload_path = str_replace( '/', DIRECTORY_SEPARATOR, $upload_dir['path'] ) . DIRECTORY_SEPARATOR;
		
			$img             = str_replace( 'data:image/'.$extension.';base64,', '', $profile_image );
			$img             = str_replace( ' ', '+', $img );
			$decoded         = base64_decode( $img );
			$filename        = '.'.$extension;
			$file_type       = 'image/'.$extension;
			$hashed_filename = md5( $filename . microtime() ) . $filename;
		
			// Save the image in the uploads directory.
			$upload_file = file_put_contents( $upload_path . $hashed_filename, $decoded );
		
			$attachment = array(
				'post_mime_type' => $file_type,
				'post_title'     => preg_replace( '/\.[^.]+$/', '', basename( $hashed_filename ) ),
				'post_content'   => '',
				'post_status'    => 'inherit',
				'guid'           => $upload_dir['url'] . '/' . basename( $hashed_filename )
			);
		
			$attach_id = wp_insert_attachment( $attachment, $upload_dir['path'] . '/' . $hashed_filename );
		
			// Regenerate Thumbnail
			global $wpdb;
			$images = $wpdb->get_results( "SELECT ID FROM $wpdb->posts WHERE post_type = 'attachment' AND post_mime_type LIKE 'image/%' AND ID ='$attach_id'" );
		
			foreach ( $images as $image ) {
				$id = $image->ID;
				$fullsizepath = get_attached_file( $id );
		
				if ( false === $fullsizepath || !file_exists($fullsizepath) )
					return;

			}
			$url = wp_get_attachment_url( $attach_id );
	
			$update = update_user_meta( $userdata->ID, 'streamit_profile_image', $url );

			if(!is_wp_error($update))
			{
				$img = get_user_meta( $userdata->ID, 'streamit_profile_image' , true ) ;  
				$data['profile_image'] = $img;
				$data['streamit_profile_image'] = $img;
			}
			
		}
		$data['message'] = $message;
		
		return comman_custom_response($data);
	}

	public function streamit_get_dashboard($request) {
	
		$parameters = $request->get_params();
	
		$masterarray = array();

		$data = stValidationToken($request);

		$user_id = null;
		if ($data['status']) {
			$user_id = $data['user_id'];
        }elseif(!$data['status'] && $data['status_code'] == 401) {
            return comman_custom_response($data,$data['status_code']);
        }

		$streamit_options =  streamit_get_options();
		
		$masterarray['register_page'] = $streamit_options['register_page'];
		$masterarray['account_page'] = $streamit_options['account_page'];
		$masterarray['login_page'] = $streamit_options['login_page'];

		$type = $parameters['type'];
			$home_option = get_option('streamit_app_'.$type);
			$masterarray['banner'] = [];
			$masterarray['sliders'] = [];

			if( !empty($home_option) ) {
				if( !empty($home_option['banner']) && count($home_option['banner']) > 0 ) {
					$banner_data = [];
					foreach( $home_option['banner'] as $banner ) {
						$bdata = streamit_movie_video_detail_helper($banner['show'],$user_id);
						
						if( !empty($bdata)){
							$banner_image = wp_get_attachment_image_src($banner['attachment'],[768, 432]);
					
							if ( !(empty($banner_image)) && $banner_image[0]) {
								$bdata['attachment'] = $banner_image[0];
							} else {
								$bdata['attachment'] = null;
							}
							$banner_data[] = $bdata;
						}
					}
					$masterarray['banner'] = $banner_data;
				}

				if( !empty($home_option['sliders']) && count($home_option['sliders']) > 0 ) {
					$slider_data = [];
					foreach( $home_option['sliders'] as $sliders ) {
						$sliderdata['title'] = $sliders['title'];
						$sliderdata['view_all'] = (bool)$sliders['view_all'];
											
						$arg['post_status'] = 'publish';
						$arg['post_type'] = ( $type == 'home' ) ? ['movie', 'tv_show','video'] : $type;

						if($sliders['filter'] != 'upcoming'){
							$arg['posts_per_page'] = (!empty($parameters['posts_per_page']) && isset($parameters['posts_per_page'])) ? $parameters['posts_per_page'] : 6;
							$arg['paged'] =  (!empty($parameters['paged']) && isset($parameters['paged'])) ? $parameters['paged'] : 1;
						}else {
							$arg['posts_per_page'] = -1;
						}
						if($sliders['filter'] == 'most_liked'){
							$like_post_type = ( $type == 'home' ) ? ['movie', 'tv_show','video'] : array($type);
							$arg['post__in'] = streamit_get_most_liked($like_post_type, [], 'id' );
							$arg['orderby'] = 'post__in';
						 } else {
							$arg['post__in'] = [];
						}

						if($sliders['filter'] == 'most_viewed' && (in_array($type ,['movie','video'])) ) {
							$arg['meta_key'] = 'post_views_count';
							$arg['orderby']	 = 'meta_value';
							$arg['order']	 = 'DESC';
						}

						if($sliders['filter'] == 'most_viewed' && $type == 'tv_show'){
							$arg['meta_key'] = 'tv_show_views_count';
							$arg['orderby']	 = 'meta_value';
							$arg['order']	 = 'DESC';
						}

						if($sliders['filter'] == 'most_viewed' && $type == 'home'){
							$arg['meta_query'] = array(
								'relation' => 'OR',
								array(
									'key' => 'post_views_count',
								),
								array(
									'key' => 'tv_show_views_count',
								)
							);
							$arg['orderby']	 = array(
								'post_views_count' => 'DESC',
								'tv_show_views_count' => 'DESC',
							);
							// $arg['order']	 = 'DESC';
						}

						$taxargs = array();
						$gener_type = '';
						
						$genre = $sliders['genre'];
						$tag = $sliders['tag'] ;
						$cat = !empty($sliders['cat']) ? $sliders['cat'] : null;

                        if(!empty($type))
                        {
                            $gener_type = $type.'_genre';
                            $tag_type = $type.'_tag';
                            $cat_type = $type.'_cat';
                            
							if($type === 'home')
                            {
								if(!empty($genre))
								{
									$tax_query_movie['taxonomy'] = 'movie_genre';
									$tax_query_movie['field'] = 'term_id';
									$tax_query_movie['terms'] = $genre;
									$tax_query_movie['operator'] = 'IN';
									array_push($taxargs, $tax_query_movie);
									$tax_query_tvshow['taxonomy'] = 'tv_show_genre';
									$tax_query_tvshow['field'] = 'term_id';
									$tax_query_tvshow['terms'] = $genre;
									$tax_query_tvshow['operator'] = 'IN';
									array_push($taxargs, $tax_query_tvshow);
								}
								if(!empty($tag))
								{
									$tax_query_mtag['taxonomy'] = 'movie_tag';
									$tax_query_mtag['field'] = 'term_id';
									$tax_query_mtag['terms'] = $tag;
									$tax_query_mtag['operator'] = 'IN';
									array_push($taxargs, $tax_query_mtag);
									$tax_query_stag['taxonomy'] = 'tv_show_tag';
									$tax_query_stag['field'] = 'term_id';
									$tax_query_stag['terms'] = $tag;
									$tax_query_stag['operator'] = 'IN';
									array_push($taxargs, $tax_query_stag);
									$tax_query_vtag['taxonomy'] = 'video_tag';
									$tax_query_vtag['field'] = 'term_id';
									$tax_query_vtag['terms'] = $tag;
									$tax_query_vtag['operator'] = 'IN';
									array_push($taxargs, $tax_query_vtag);
								}
								if(!empty($cat))
								{
									$tax_query_vcat['taxonomy'] = 'video_cat';
									$tax_query_vcat['field'] = 'term_id';
									$tax_query_vcat['terms'] = $cat;
									$tax_query_vcat['operator'] = 'IN';
									array_push($taxargs, $tax_query_vcat);
								}
                            }
                        }
                        if(!empty($genre) && !empty($gener_type) && $type !== 'home' && $type !== 'video')
                        {
                            $tax_query['taxonomy'] = $gener_type;
                            $tax_query['field'] = 'term_id';
                            $tax_query['terms'] = $genre;
                            $tax_query['operator'] = 'IN';
                            array_push($taxargs, $tax_query);
                        }
                        if(!empty($tag)&& !empty($tag_type) && $type !== 'home')
                        {
                            $tax_query['taxonomy'] = $tag_type;
                            $tax_query['field'] = 'term_id';
                            $tax_query['terms'] = $tag;
                            $tax_query['operator'] = 'IN';
                            array_push($taxargs, $tax_query);
                        
                        }
						if(!empty($cat)&& !empty($cat_type) && $type === 'video')
                        {
                            $tax_query['taxonomy'] = $cat_type;
                            $tax_query['field'] = 'term_id';
                            $tax_query['terms'] = $cat;
                            $tax_query['operator'] = 'IN';
                            array_push($taxargs, $tax_query);
                        
                        }
                        if(!empty($taxargs))
                        {
                            $arg['tax_query'] = $taxargs;
                            $arg['tax_query']['relation'] = 'OR';
						}
						if ( !empty($sliders['select_movie_show']) ) {
							$arg['post__in'] = $sliders['select_movie_show'];
						}

						$movie_show_data = new WP_Query( $arg );
						$sdata = [];
						if($movie_show_data->have_posts()) {
							while($movie_show_data->have_posts()) {
								$movie_show_data->the_post();
								
								$slider = streamit_movie_video_detail_helper(get_the_ID(),$user_id);
								if($sliders['filter'] == 'upcoming' && ($slider['name_upcoming'] == '' || $slider['name_upcoming'] ==  null)){
								 	continue;
								}
								$sdata[] = $slider;
								
							}
						}
						$arg = [];
						$sliderdata['data'] = array_slice($sdata,0,6);
						$slider_data[] = $sliderdata;
					}
					$masterarray['sliders'] = $slider_data;
				}
			} else {
				$masterarray['banner'] = [];
				$masterarray['sliders'] = [];
			}

		return comman_custom_response ($masterarray);
	}

	public function streamit_slider_view_all($request) {
	
		$parameters = $request->get_params();
	
		$masterarray = array();

		$slider_data = [];
		$data = stValidationToken($request);

		$user_id = null;
		if ($data['status']) {
			$user_id = $data['user_id'];
        }elseif(!$data['status'] && $data['status_code'] == 401) {
            return comman_custom_response($data,$data['status_code']);
        }

		$type = $parameters['type'];
		$slider_id = (!empty($parameters['slider_id']) && isset($parameters['slider_id'])) ? $parameters['slider_id'] : 0;
			$home_option = get_option('streamit_app_'.$type);

			if( !empty($home_option) ) {

				if( !empty($home_option['sliders']) && count($home_option['sliders']) >= $slider_id ) {
					
					$sliders = $home_option['sliders'][$slider_id];
					// foreach( $home_option['sliders'] as $sliders ) {
						$sliderdata['title'] = $sliders['title'];
						$genre = $sliders['genre'];
						$tag = $sliders['tag'] ;
						$cat = !empty($sliders['cat']) ? $sliders['cat'] : null;
						if($sliders['filter'] != 'upcoming'){
							$arg['posts_per_page'] = (!empty($parameters['posts_per_page']) && isset($parameters['posts_per_page'])) ? $parameters['posts_per_page'] : 20;
							$arg['paged'] =  (!empty($parameters['paged']) && isset($parameters['paged'])) ? $parameters['paged'] : 1;
						}else {
							$arg['posts_per_page'] = -1;
						}
						$arg['post_status'] = 'publish';
						$arg['post_type'] = ( $type == 'home' ) ? ['movie', 'tv_show','video'] : $type;

						if( $sliders['filter'] == 'latest' ){
							$arg['order'] = 'DESC';
							$arg['orderby'] = 'publish_date';
						}
						if($sliders['filter'] == 'most_liked'){
							$like_post_type = ( $type == 'home' ) ? ['movie', 'tv_show','video'] : array($type);
							$arg['post__in'] = streamit_get_most_liked($like_post_type, [], 'id' );
							$arg['orderby'] = 'post__in';
						}else {
							$arg['post__in'] = [];
						}

						if($sliders['filter'] == 'most_viewed' && (in_array($type ,['movie','video'])) ) {
							$arg['meta_key'] = 'post_views_count';
							$arg['orderby']	 = 'meta_value';
							$arg['order']	 = 'DESC';
						}

						if($sliders['filter'] == 'most_viewed' && $type == 'tv_show'){
							$arg['meta_key'] = 'tv_show_views_count';
							$arg['orderby']	 = 'meta_value';
							$arg['order']	 = 'DESC';
						}

						if($sliders['filter'] == 'most_viewed' && $type == 'home'){
							$arg['meta_query'] = array(
								'relation' => 'OR',
								array(
									'key' => 'post_views_count',
								),
								array(
									'key' => 'tv_show_views_count',
								)
							);
							$arg['orderby']	 = array(
								'post_views_count' => 'DESC',
								'tv_show_views_count' => 'DESC',
							);
							// $arg['order']	 = 'DESC';
						}
						$taxargs = array();
                        $gener_type = '';
						if(!empty($type))
                        {
                            $gener_type = $type.'_genre';
                            $tag_type = $type.'_tag';
                            $cat_type = $type.'_cat';
                            
							if($type === 'home')
                            {
								if(!empty($genre))
								{
									$tax_query_movie['taxonomy'] = 'movie_genre';
									$tax_query_movie['field'] = 'term_id';
									$tax_query_movie['terms'] = $genre;
									$tax_query_movie['operator'] = 'IN';
									array_push($taxargs, $tax_query_movie);
									$tax_query_tvshow['taxonomy'] = 'tv_show_genre';
									$tax_query_tvshow['field'] = 'term_id';
									$tax_query_tvshow['terms'] = $genre;
									$tax_query_tvshow['operator'] = 'IN';
									array_push($taxargs, $tax_query_tvshow);
								}
								if(!empty($tag))
								{
									$tax_query_mtag['taxonomy'] = 'movie_tag';
									$tax_query_mtag['field'] = 'term_id';
									$tax_query_mtag['terms'] = $tag;
									$tax_query_mtag['operator'] = 'IN';
									array_push($taxargs, $tax_query_mtag);
									$tax_query_stag['taxonomy'] = 'tv_show_tag';
									$tax_query_stag['field'] = 'term_id';
									$tax_query_stag['terms'] = $tag;
									$tax_query_stag['operator'] = 'IN';
									array_push($taxargs, $tax_query_stag);
									$tax_query_vtag['taxonomy'] = 'video_tag';
									$tax_query_vtag['field'] = 'term_id';
									$tax_query_vtag['terms'] = $tag;
									$tax_query_vtag['operator'] = 'IN';
									array_push($taxargs, $tax_query_vtag);
								}
								if(!empty($cat))
								{
									$tax_query_vcat['taxonomy'] = 'video_cat';
									$tax_query_vcat['field'] = 'term_id';
									$tax_query_vcat['terms'] = $cat;
									$tax_query_vcat['operator'] = 'IN';
									array_push($taxargs, $tax_query_vcat);
								}
                            }
                        }
                        if(!empty($genre) && !empty($gener_type) && $type !== 'home' && $type !== 'video')
                        {
                            $tax_query['taxonomy'] = $gener_type;
                            $tax_query['field'] = 'term_id';
                            $tax_query['terms'] = $genre;
                            $tax_query['operator'] = 'IN';
                            array_push($taxargs, $tax_query);
                        }
                        if(!empty($tag)&& !empty($tag_type) && $type !== 'home')
                        {
                            $tax_query['taxonomy'] = $tag_type;
                            $tax_query['field'] = 'term_id';
                            $tax_query['terms'] = $tag;
                            $tax_query['operator'] = 'IN';
                            array_push($taxargs, $tax_query);
                        
                        }
						if(!empty($cat)&& !empty($cat_type) && $type === 'video')
                        {
                            $tax_query['taxonomy'] = $cat_type;
                            $tax_query['field'] = 'term_id';
                            $tax_query['terms'] = $cat;
                            $tax_query['operator'] = 'IN';
                            array_push($taxargs, $tax_query);
                        
                        }
                        if(!empty($taxargs))
                        {
                            $arg['tax_query'] = $taxargs;
                            $arg['tax_query']['relation'] = 'OR';
						}
						if ( !empty($sliders['select_movie_show']) ) {
							$arg['post__in'] = $sliders['select_movie_show'];
						}
						$movie_show_data = new WP_Query( $arg );

						$sdata = [];
						if($movie_show_data->have_posts()) {
							while($movie_show_data->have_posts()) {
								$movie_show_data->the_post();
								$slider = streamit_movie_video_detail_helper(get_the_ID(),$user_id);
								if($sliders['filter'] == 'upcoming' && ($slider['name_upcoming'] == '' || $slider['name_upcoming'] ==  null)){
								 	continue;
								}
								$sdata[] = $slider;
							}
						}
						$arg = [];
						$sliderdata['data'] = $sdata;
						$slider_data = $sliderdata;
					// }
				}
			}

		return comman_custom_response ($slider_data);
	}

	public function streamit_view_profile ( $request) {
		$data = stValidationToken($request);

		if ($data['status']) {
			$user_id = $data['user_id'];
        }elseif(!$data['status'] && $data['status_code'] == 401) {
            return comman_custom_response($data,$data['status_code']);
        }

		$img       = get_user_meta( $user_id, 'streamit_profile_image' , true);
		$user_info = get_userdata( $user_id );

		$response['first_name'] = $user_info->first_name;
		$response['last_name']  = $user_info->last_name;
		$response['user_id']    = $user_info->ID;
		$response['username']	= $user_info->user_login;
		$response['user_email']		= $user_info->user_email;
		$response['plan'] = streamit_user_plans($user_info->ID);
		$response['profile_image'] = $img;
		$response['streamit_profile_image'] = $img;
		
		return comman_custom_response($response);
	}

	public function streamit_v2_update_profile($request) {

		$parameters = $request->get_params();
        
        $data = stValidationToken($request);

		if ($data['status']) {
			$userid = $data['user_id'];
        }elseif(!$data['status'] && $data['status_code'] == 401) {
            return comman_custom_response($data,$data['status_code']);
        }

        $reqArr = $request->get_params();

		$userid = $data['user_id'];

		wp_update_user([
			'ID' => $userid,
			'first_name' => $reqArr['first_name'],
			'last_name' => $reqArr['last_name'],
			'display_name' => $reqArr['first_name'].' '.$reqArr['last_name']
		]);

        $users = get_userdata( $userid );

		$response = [
			'ID'			=> $users->ID,
			'first_name' 	=> $users->first_name,
			'last_name' 	=> $users->last_name,
			'user_email' 	=> $users->user_email,
			'user_login' 	=> $users->user_login,
			'display_name'  => $users->display_name
		];

		if( isset($_FILES['profile_image']) && $_FILES['profile_image'] != null ){
            $profile_image = media_handle_upload( 'profile_image', 0 );

            update_user_meta( $userid, 'streamit_profile_image', wp_get_attachment_url($profile_image) );
        }
		$response['profile_image'] = get_user_meta($userid, 'streamit_profile_image', true );
		$response['streamit_profile_image'] = get_user_meta($userid, 'streamit_profile_image', true );

		$response['message'] = 'Profile has been updated succesfully';
        
        return comman_custom_response( $response );
	}

	public function streamit_get_genre($request){
		
		$parameters = $request->get_params();
		
		$paged = (!empty($parameters['paged']) && isset($parameters['paged'])) ? $parameters['paged'] : 1;
		$posts_per_page = (!empty($parameters['posts_per_page']) && isset($parameters['posts_per_page'])) ? $parameters['posts_per_page'] : 10;
		$type = $parameters['type'] .'_genre';
		
		// In video use category as genre
		if( $parameters['type'] == 'video' )
		{
			$type = 'video_cat';
		}
		if($paged < 1) $paged = 1;
	
		$args = array(
			'taxonomy'  => $type,
			'number'    => $posts_per_page,
			'offset'    => ($paged - 1) * $posts_per_page,
			'orderby'   => 'name',
			'order'     => 'ASC',
			'hide_empty'    => false,
		
		);
		$query = new WP_Term_Query($args);
		$generList = $query->terms;	
		return collect($generList)->map(function ($res, $key)  {
			$image = '';
			$thumbnail_id = get_term_meta($res->term_id, 'thumbnail_id', true);
			if ($thumbnail_id) {
				$image = wp_get_attachment_thumb_url($thumbnail_id);
			}
			return ['id' => $res->term_id, 'name' => $res->name ,'slug' => $res->slug , 'genre_image' => $image];
		})->values();
	}

	public function streamit_get_list_by_genre($request){
        $movie_array = array();

        $parameters = $request->get_params();

		$movie_genre_list = $parameters['genre'];
		$movie_genre_array = explode(',', $movie_genre_list);

		$args['posts_per_page'] = (!empty($parameters['posts_per_page']) && isset($parameters['posts_per_page'])) ? $parameters['posts_per_page'] : 10;
		$args['paged'] =  (!empty($parameters['paged']) && isset($parameters['paged'])) ? $parameters['paged'] : 1;
    
        $type = $parameters['type'] .'_genre';
		
		// In video use category as genre
		if( $parameters['type'] == 'video' )
		{
			$type = 'video_cat';
		}
        $args['post_type'] 		= $parameters['type'];
        $args['post_status']    = 'publish';
		$args['tax_query'] =  array(
			array(
                'taxonomy' => $type,
                'field' => 'slug',
                'terms' => $movie_genre_array,
            )
		);

        $wp_query = new WP_Query($args);
        $num_pages = $wp_query->max_num_pages;

        $data = stValidationToken($request);

		$user_id = null;
		if ($data['status']) {
			$user_id = $data['user_id'];
        }elseif(!$data['status'] && $data['status_code'] == 401) {
            return comman_custom_response($data,$data['status_code']);
        }	
        if($wp_query->have_posts())
        {
            while($wp_query->have_posts()) {
                $wp_query->the_post();
                $movie_array[] = streamit_movie_video_detail_helper(get_the_ID(),$user_id);
            }
        }
    
        return comman_list_response($movie_array);
	}	
	public function streamit_delete_user_account($request){
		$parameters = $request->get_params();
        $data = stValidationToken($request);
		if ($data['status']) {
			$user_id = $data['user_id'];
        }elseif(!$data['status'] && $data['status_code'] == 401) {
            return comman_custom_response($data,$data['status_code']);
        }
		$user= wp_delete_user($user_id,true);
		if($user){
			return comman_message_response(__('User Deleted Successfully'),200);
		}else{
			return comman_message_response(__('User not Deleted'),422);
		}
	}
}