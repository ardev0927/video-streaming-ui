<?php

namespace Includes\Controllers\Api;

use Includes\baseClasses\STBase;
use WP_REST_Response;
use WP_REST_Server;
use WP_Query;
class STTVShowController extends STBase {

	public $module = 'tv_show';

	public $nameSpace;

	function __construct() {

		$this->nameSpace = STREAMIT_API_NAMESPACE;

		add_action( 'rest_api_init', function () {

			register_rest_route( $this->nameSpace . '/api/v1/' . $this->module, '/get_tv_shows', array(
				'methods'             => WP_REST_Server::ALLMETHODS,
				'callback'            => [ $this, 'streamit_get_tv_shows' ],
				'permission_callback' => '__return_true'
            ) );
            
            register_rest_route( $this->nameSpace . '/api/v1/' . $this->module, '/get_tv_show_detail', array(
				'methods'             => WP_REST_Server::ALLMETHODS,
				'callback'            => [ $this, 'streamit_get_tv_show_detail' ],
				'permission_callback' => '__return_true'
            ) );  

		} );
	}


    public function streamit_get_tv_shows ($request) {

        $data = array();
        $tv_show_array = array();
        $parameters = $request->get_params();
        
        $page = 1;
        $per_page = 4 ;
        $num_pages = 1;

        if (isset($parameters['page'])) {
            $page = $parameters['page'];
        }

        if (isset($parameters['per_page'])) {
            $per_page = $parameters['per_page'];
        }

        $args['post_type']      = 'tv_show';
        $args['post_status']    = 'publish';
        $args['posts_per_page'] = $per_page ;
        $args['paged'] = $page;
        $wp_query = new WP_Query( $args );

        $data = stValidationToken($request);
        $user_id = null;
		if ($data['status']) {
			$user_id = $data['user_id'];
        }elseif(!$data['status'] && $data['status_code'] == 401) {
            return comman_custom_response($data,$data['status_code']);
        }
        if($wp_query->have_posts()) {
            while($wp_query->have_posts()) {
                $wp_query->the_post();
                $tv_show_array[] = streamit_movie_video_detail_helper(get_the_ID(),$user_id);
            }
        }

        return comman_list_response($tv_show_array);

    }

    public function streamit_get_tv_show_detail($request) {
        $parameters = $request->get_params();

        $tv_show_id = $parameters['tv_show_id'];
        $args['p'] =  $tv_show_id;
        $args['post_type']      = 'tv_show';
        $args['post_status']    = 'publish';
        $response = [];
        $wp_query = new WP_Query( $args );
        
        $tv_show = $wp_query->post;
        $wp_query = new WP_Query($args);
        $response_data = $wp_query->post;
        $post_meta = get_post_meta($tv_show_id);
        $tv_show_season = get_post_meta($tv_show_id, '_seasons');
        
        $data = stValidationToken($request);

		$user_id = null;
		if ($data['status']) {
			$user_id = $data['user_id'];
        }elseif(!$data['status'] && $data['status_code'] == 401) {
            return comman_custom_response($data,$data['status_code']);
        }
        if (isset($response_data) && $response_data !== null && $response_data !== '') {
            $response = streamit_movie_video_detail_helper_detail($tv_show_id,$user_id);
            
            $seasons = [];

            if( !empty($tv_show_season[0]) && count($tv_show_season[0]) > 0 ){
                foreach( $tv_show_season[0] as $season ){
                    $episode_data['name'] = $season['name'];
                    $episode_data['description'] = $season['description'];
                    $episode_data['year'] = $season['year'];
                    $episode_data['position'] = $season['position'];
                    $full_image = wp_get_attachment_image_src($season['image_id'],[300, 300]);
                    
                    if ($full_image[0]) {
                        $episode_data['image'] = $full_image[0];
                    } else {
                        $episode_data['image'] = null;
                    }

                    if( count($season['episodes']) > 0 ) {
                        $episodes = [];
                        foreach( $season['episodes'] as $episode ){
                            $episode_data['episode'][] = streamit_movie_video_detail_helper($episode,$user_id);
                        }
                    }
                    array_push($seasons,$episode_data);
                    $episode_data['episode'] = [];
                }
            }
        }

        $response = array('data' => $response , "seasons" => $seasons);
        return comman_custom_response($response);
        
    }

}