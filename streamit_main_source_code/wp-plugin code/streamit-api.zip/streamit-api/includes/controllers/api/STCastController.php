<?php

namespace Includes\Controllers\Api;

use Includes\baseClasses\STBase;
use WP_REST_Response;
use WP_REST_Server;
use WP_Query;
class STCastController extends STBase {

	public $module = 'cast';

	public $nameSpace;

	function __construct() {

		$this->nameSpace = STREAMIT_API_NAMESPACE;

		add_action( 'rest_api_init', function () {	

            register_rest_route( $this->nameSpace . '/api/v1/' . $this->module, '/get-detail', array(
				'methods'             => WP_REST_Server::ALLMETHODS,
				'callback'            => [ $this, 'streamit_get_cast_detail' ],
				'permission_callback' => '__return_true'
            ) );

			register_rest_route( $this->nameSpace . '/api/v1/' . $this->module, '/get-movie-show-list', array(
				'methods'             => WP_REST_Server::ALLMETHODS,
				'callback'            => [ $this, 'streamit_cast_movie_tab_list' ],
				'permission_callback' => '__return_true'
            ) );
			
		} );
	}

    public function streamit_get_cast_detail($request)
    {
		$parameters = $request->get_params();	

		$cast_id = $parameters['cast_id'];
		$data = stValidationToken($request);

		$user_id = null;
		if ($data['status']) {
			$user_id = $data['user_id'];
		}

		$most_view_movie_tv_show = [];
		$all_movie_tv_show = [];
		$movie = [];
		$tv_show = [];
		$response = null;
		$args['p'] =  $cast_id ;
        $args['post_type'] = 'person';

        $wp_query = new WP_Query($args);
        $response_data = $wp_query->post;
		if (isset($response_data) && $response_data !== null && $response_data !== '') {

			$list = get_post($cast_id);

			if( empty($list) && $list === null) {
				return (object) [];
			}

			$terms = get_the_terms( $list->ID, 'person_cat' );
			$term_names = "";
			if( $terms && !(is_wp_error( $terms )) )
			{
				$term_names = wp_list_pluck( $terms, 'name' );
				$term_names = implode(',',$term_names);
			}

			$movie_cast = (array) get_post_meta($list->ID , '_movie_cast',true);
			$movie_crew = (array) get_post_meta($list->ID , '_movie_crew', true);
			$tv_show_cast = (array) get_post_meta($list->ID , '_tv_show_cast', true);
			$tv_show_crew = (array) get_post_meta($list->ID , '_tv_show_crew', true);
			$credits = array_unique( array_merge ( $movie_cast, $movie_crew, $tv_show_cast, $tv_show_crew ) );

			$cast_movie_tv_show = array_merge($movie_cast,$tv_show_cast);

			$cast_image = wp_get_attachment_image_src(get_post_thumbnail_id($list->ID), "full");

			$birthday = empty(get_post_meta($list->ID,'_birthday',true)) ? null : date_i18n('Y-m-d', get_post_meta($list->ID,'_birthday',true));
			$deathday = empty(get_post_meta($list->ID,'_deathday',true)) ? null : date_i18n('Y-m-d', get_post_meta($list->ID,'_deathday',true));
			
			$response = [
				'id'		=> $list->ID,
				'title'		=> get_the_title($list->ID),
				'description' => wp_strip_all_tags(get_the_content(null,false,$list->ID)),
				'image'     => !empty($cast_image) ? $cast_image[0] : null,
				'category'  => $term_names,
				'credits'	=> count($credits),
				'also_known_as' => get_post_meta($list->ID , '_also_known_as', true),
				'place_of_birth' => get_post_meta($list->ID,'_place_of_birth',true),
				'birthday' => $birthday,
				'deathday' => $deathday,
			];

			$args = array(
				'post_type' => array('movie', 'tv_show'),
				'post_status' => 'publish',
				'post__in' => $cast_movie_tv_show,
				'orderby'           => 'meta_value_num',
				'order'             => 'DESC',
				'posts_per_page'    => 10,
				'meta_query' => array(
				   'relation' => 'AND',
					array(
						'relation' => 'OR',
						array(
							'key' => 'post_views_count',
						),
						array(
							'key' => 'tv_show_views_count',
						)
					),
				)
			);
			$most_view = new WP_Query($args);
			
			if($most_view->have_posts())
			{
				while($most_view->have_posts()) {
					$most_view->the_post();
					$most_view_movie_tv_show[] = streamit_movie_video_detail_helper(get_the_ID(),$user_id);
				}
			}
			$args = array(
				'post_status' => 'publish',
				'order'             => 'ASC',
				'posts_per_page'    => 10,
				'suppress_filters'  => 0
			);
			$args_all = array(
				'post_type' => array('movie', 'tv_show'),
				'post__in' => $cast_movie_tv_show,
			);

			$args_all = array_merge($args_all,$args);

			$all = new WP_Query($args_all);
			
			if($all->have_posts())
			{
				while($all->have_posts()) {
					$all->the_post();
					$all_movie_tv_show[] = streamit_movie_show_cast_detail_helper(get_the_ID(),$cast_id);
				}
			}

			$args_movie = array(
				'post_type' 	=> array('movie'),
				'post__in' 		=> $movie_cast,
			);
			$args_movie = array_merge($args_movie,$args);

			$movie_query = new WP_Query($args_movie);
			
			if($movie_query->have_posts())
			{
				while($movie_query->have_posts()) {
					$movie_query->the_post();
					$movie[] = streamit_movie_show_cast_detail_helper(get_the_ID(),$cast_id);
				}
			}

			$args_tv_show = array(
				'post_type'		=> array('tv_show'),
				'post__in'		=> $tv_show_cast,
			);
			$args_tv_show = array_merge($args_tv_show,$args);

			$tv_show_query = new WP_Query($args_tv_show);
			
			if($tv_show_query->have_posts())
			{
				while($tv_show_query->have_posts()) {
					$tv_show_query->the_post();
					$tv_show[] = streamit_movie_show_cast_detail_helper(get_the_ID(),$cast_id);
				}
			}
        }

		$responses = array('data' => $response,'most_view_movie_tv_show' => $most_view_movie_tv_show, 'all_movie_tv_show' => $all_movie_tv_show , 'movie' => $movie ,'tv_show' => $tv_show );

        return comman_custom_response($responses);

    }

	public function streamit_cast_movie_tab_list($request)
	{
		$parameters = $request->get_params();	

		$cast_id = $parameters['cast_id'];
		$data = stValidationToken($request);

		$user_id = null;
		if ($data['status']) {
			$user_id = $data['user_id'];
		}
		$response = [];
		$args['p'] =  $cast_id ;
        $args['post_type'] = 'person';

        $wp_query = new WP_Query($args);
        $response_data = $wp_query->post;
		if (isset($response_data) && $response_data !== null && $response_data !== '')
		{

			$list = get_post($cast_id);

			if( empty($list) && $list === null) {
				return (object) [];
			}

			$movie_cast = get_post_meta($list->ID , '_movie_cast',true);
			$tv_show_cast = get_post_meta($list->ID , '_tv_show_cast', true);
			$type = !empty($parameters['type']) ? $parameters['type'] : array('movie', 'tv_show');
			
			$movie_cast = (array) get_post_meta($list->ID , '_movie_cast',true);
			$movie_crew = (array) get_post_meta($list->ID , '_movie_crew', true);
			$tv_show_cast = (array) get_post_meta($list->ID , '_tv_show_cast', true);
			$tv_show_crew = (array) get_post_meta($list->ID , '_tv_show_crew', true);
			
			if($type == 'movie')
			{
				$cast_in = $movie_cast;
			}elseif($type == 'tv_show') {
				$cast_in = $tv_show_cast;
			} else {
				$cast_in = array_merge($movie_cast,$tv_show_cast);
			}

			$args = array(
				'post_type' => $type,
				'post_status' => 'publish',
				'post__in'    => $cast_in,
				'order'             => 'ASC',
				'posts_per_page'    => (!empty($parameters['posts_per_page']) && isset($parameters['posts_per_page'])) ? $parameters['posts_per_page'] : 10,
				'suppress_filters'  => 0,
				'paged' 			=>  (!empty($parameters['paged']) && isset($parameters['paged'])) ? $parameters['paged'] : 1,
			);

			$cast_movie = new WP_Query($args);
			
			if($cast_movie->have_posts())
			{
				while($cast_movie->have_posts()) {
					$cast_movie->the_post();
					$response[] = streamit_movie_show_cast_detail_helper(get_the_ID(),$cast_id);
				}
			}
		}
		return comman_custom_response($response);
	}
}