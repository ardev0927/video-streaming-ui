<?php

namespace Includes\Controllers\Api;

use Includes\baseClasses\STBase;
use WP_REST_Response;
use WP_REST_Server;
use WP_Query;
class STMovieController extends STBase {

	public $module = 'movie';

	public $nameSpace;

	function __construct() {

		$this->nameSpace = STREAMIT_API_NAMESPACE;

		add_action( 'rest_api_init', function () {

			register_rest_route( $this->nameSpace . '/api/v1/' . $this->module, '/get_list', array(
				'methods'             => WP_REST_Server::ALLMETHODS,
				'callback'            => [ $this, 'streamit_get_movies' ],
				'permission_callback' => '__return_true'
            ) );

            register_rest_route( $this->nameSpace . '/api/v1/' . $this->module, '/get-detail', array(
				'methods'             => WP_REST_Server::ALLMETHODS,
				'callback'            => [ $this, 'streamit_get_movie_detail' ],
				'permission_callback' => '__return_true'
            ) );


		} );
	}

    public function streamit_get_movies ($request) {

        $movies_array = array();
        $movie_array = array();
        $parameters = $request->get_params();
        $header = $request->get_headers();
        $page = 1;
        $per_page = 10 ;
        $num_pages = 1;
    
        if (isset($parameters['page'])) {
            $page = $parameters['page'];
        }
    
        if (isset($parameters['per_page'])) {
            $per_page = $parameters['per_page'];
        }
    
        $args['post_type']      = 'movie';
        $args['post_status']    = 'publish';
        $args['posts_per_page'] = $per_page ;
        $args['paged'] = $page;
    
        $wp_query = new WP_Query($args);
        $num_pages = $wp_query->max_num_pages;

        $data = stValidationToken($request);

		$user_id = null;
		if ($data['status']) {
			$user_id = $data['user_id'];
        }elseif(!$data['status'] && $data['status_code'] == 401) {
            return comman_custom_response($data,$data['status_code']);
        }
        if($wp_query->have_posts())
        {
            while($wp_query->have_posts()) {
                $wp_query->the_post();
                $movie_array[] = streamit_movie_video_detail_helper(get_the_ID(),$user_id);
            }
        }
    
        return comman_list_response($movie_array);
    
    }

    public function streamit_get_movie_detail ($request) {
        $parameters = $request->get_params();
        $header = $request->get_headers();
        $response = [];
        
        $movie_id = $parameters['movie_id'];
        $args['p'] =  $movie_id ;
        $args['post_type']      = 'movie';
        $args['post_status']    = 'publish';
        $wp_query = new WP_Query($args);
        $response_data = $wp_query->post;

        $data = stValidationToken($request);

		$user_id = null;
		if ($data['status']) {
			$user_id = $data['user_id'];
        }elseif(!$data['status'] && $data['status_code'] == 401) {
            return comman_custom_response($data,$data['status_code']);
        }
        user_posts_view_count($movie_id);
        if (isset($response_data) && $response_data !== null && $response_data !== '') {
            $response = streamit_movie_video_detail_helper_detail($movie_id,$user_id);
        }
        $recommended_movie = [];
    
        $recommended_movie_ids = get_post_meta($movie_id, '_recommended_movie_ids')[0];
        
        if(count($recommended_movie_ids) > 0) {
            foreach($recommended_movie_ids as $movie) {
                $recommended_movie[] = streamit_movie_video_detail_helper($movie,$user_id);
            }
    
        }
        $arg = array(
            'post_type' => 'movie',
            'post_status' => 'publish',
            'meta_key' => 'name_upcoming',
            'meta_query' => array (
                'key' => 'name_upcoming',
                'value'   => 'yes',
                'compare' => 'LIKE'
            ),
            'post__not_in' => array ($movie_id)
        );
        $upcomming = new WP_Query($arg);
        $upcomming_movie = [];
        if($upcomming->have_posts())
        {
            while($upcomming->have_posts()) {
                $upcomming->the_post();
                $upcomming_movie[] = streamit_movie_video_detail_helper(get_the_ID(),$user_id);
            }
        }
        $response = array('data' => $response , 'recommended_movie' => $recommended_movie , 'upcomming_movie' => $upcomming_movie);
        return comman_custom_response($response);
    
    }

}