<?php

namespace Includes\Controllers\Api;

use Includes\baseClasses\STBase;
use WP_REST_Response;
use WP_REST_Server;
use WP_Query;

class STPricingPlanController extends STBase {

	public $module = 'pricing-plan';

	public $nameSpace;

	function __construct() {

		$this->nameSpace = STREAMIT_API_NAMESPACE;

		add_action( 'rest_api_init', function () {

			register_rest_route( $this->nameSpace . '/api/v1/' . $this->module, '/get-list', array(
				'methods'             => WP_REST_Server::ALLMETHODS,
				'callback'            => [ $this, 'streamit_pricing_plan_list' ],
				'permission_callback' => '__return_true'
            ));

            register_rest_route( $this->nameSpace . '/api/v1/' . $this->module, '/get-detail', array(
				'methods'             => WP_REST_Server::ALLMETHODS,
				'callback'            => [ $this, 'streamit_pricing_plan_detail' ],
				'permission_callback' => '__return_true'
            ));

            register_rest_route( $this->nameSpace . '/api/v1/' . $this->module, '/payment-history', array(
				'methods'             => WP_REST_Server::ALLMETHODS,
				'callback'            => [ $this, 'streamit_pricing_plan_payment_history' ],
				'permission_callback' => '__return_true'
            ));
        });
    }
    public function streamit_pricing_plan_list ($request) {

        $parameters = $request->get_params();

        $args['post_type']      = 'pms-subscription';
        $args['post_status']    = 'active';
        $wp_query = new WP_Query($args);
        $response = [];

        if($wp_query->have_posts()) {
            while($wp_query->have_posts()) {
                $wp_query->the_post();
                $response[] = streamit_pricing_plan(get_the_ID());
            }
        }
        return comman_custom_response($response);
    }

    public function streamit_pricing_plan_detail ($request ) {
        $parameters = $request->get_params();

        $subscription_id = $parameters['subscription_id'];

        // $args = array(
        //     'post_type'     => 'pricing',
        //     'post_status'   => 'publish',
        //     'meta_query'    => array(
        //         array (
        //             'key' => 'name_paid_sub_id',
        //             'value'   => $subscription_id
        //             )
        //         )
        //     );
        // $my_query = new WP_Query( $args );
        // $pricing_plan_data = [];
        // if( $my_query->have_posts() ) {
        //     while( $my_query->have_posts() ) {
        //         $my_query->the_post();
        //         $post_data = get_post(get_the_ID());
        //         $post_data->plan_category = streamit_get_custom_taxonomy('pricing_categories',get_the_ID());
        //     }
        // }
        $post_data = pricing_plan_detail($subscription_id);



        return comman_custom_response($post_data);
            
    }

    public function streamit_pricing_plan_payment_history ($request ) {
        $data = stValidationToken($request);

		if (!$data['status']) {
			return comman_custom_response($data,401);
        }
        
        $user_id = $data['user_id'];
        $number_per_page = (!empty($parameters['posts_per_page']) && isset($parameters['posts_per_page'])) ? $parameters['posts_per_page'] : 10;
        $page =  (!empty($parameters['paged']) && isset($parameters['paged'])) ? $parameters['paged'] : 1;
        
        $payments = pms_get_payments( array(
            'order'   => 'DESC',
            'user_id' => $user_id,
            'number'  => $number_per_page,
            'offset'  => ( $page !== 1 ? ( $page - 1 ) * $number_per_page : '' )
        ));

        if( !empty($payments) && count($payments) > 0 ){
            $payments = collect($payments)->map( function ($payment) {
                $payment_statuses = pms_get_payment_statuses();

                $payment->amount = pms_format_price( $payment->amount , pms_get_active_currency() );
                $payment->date = ucfirst( date_i18n( apply_filters( 'pms_payment_history_date_format', 'j F, Y H:i' ), strtotime( $payment->date ) + ( get_option( 'gmt_offset' ) * HOUR_IN_SECONDS ) ) );
                $payment->status = !empty( $payment_statuses[$payment->status] ) ? $payment_statuses[$payment->status] : '';
                return $payment;
            });
        }

        return comman_custom_response($payments);
    }

}