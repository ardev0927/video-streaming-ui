<?php

namespace Includes\Controllers\Api;

use Includes\baseClasses\STBase;
use WP_REST_Response;
use WP_REST_Server;
use WP_Query;
class STEpisodeController extends STBase {

	public $module = 'tv_show_episode';

	public $nameSpace;

	function __construct() {

		$this->nameSpace = STREAMIT_API_NAMESPACE;

		add_action( 'rest_api_init', function () {

			register_rest_route( $this->nameSpace . '/api/v1/' . $this->module, '/get_episode_detail', array(
				'methods'             => WP_REST_Server::ALLMETHODS,
				'callback'            => [ $this, 'streamit_get_episode_detail' ],
				'permission_callback' => '__return_true'
            ) );

		} );
	}
   
        
    public function streamit_get_episode_detail($request) {
        $parameters = $request->get_params();
        $header = $request->get_headers();
        $episode_id = $parameters['episode_id'];
        $args['p'] =  $episode_id;
        $args['post_type']      = 'episode';
        $args['post_status']    = 'publish';
        $response = [];
        $wp_query = new WP_Query( $args );
        
        $tv_show = $wp_query->post;
        $wp_query = new WP_Query($args);
        $response_data = $wp_query->post;
        $post_meta = get_post_meta($episode_id);
        
        $data = stValidationToken($request);
        $user_id = null;
		if ($data['status']) {
			$user_id = $data['user_id'];
        } elseif(!$data['status'] && $data['status_code'] == 401) {
            return comman_custom_response($data,$data['status_code']);
        }
        if (isset($response_data) && $response_data !== null && $response_data !== '') {
            $response = streamit_movie_video_detail_helper_detail($episode_id,$user_id);
        }
        user_posts_view_count($episode_id);
        // $response = array('data' => $response);
        return comman_custom_response($response);
    }
}