<?php


namespace Includes\Controllers\Admin;


use Includes\baseClasses\STBase;

class HomeController extends STBase
{

}